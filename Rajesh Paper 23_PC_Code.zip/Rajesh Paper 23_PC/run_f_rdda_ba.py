"""
Primary Execution Script: f-RDDA-BA Framework
Runs end-to-end simulation across MIT-BIH, PTB-XL, and Chapman-Shaoxing datasets,
evaluates all 15 performance metrics, and logs comprehensive research results.
"""

import os
import sys
import json
import time

# Ensure project root is in sys.path
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from src.config import get_default_config, RESULTS_DIR, FIGURES_DIR
from src.data.ecg_datasets import ECGDatasetManager
from src.federated.coordinator import FRDDABACoordinator
from src.metrics.evaluator import MetricsEvaluator
from src.visualization.plotter import BenchmarkVisualizer


def run_single_dataset_pipeline(dataset_key: str, num_rounds: int = 25):
    """Executes f-RDDA-BA pipeline for a single dataset and computes all 15 metrics."""
    print(f"\n{'='*75}")
    print(f"🚀 INITIATING f-RDDA-BA PIPELINE: {dataset_key.upper()}")
    print(f"{'='*75}")

    config = get_default_config(dataset_key)
    config.federated.num_global_rounds = num_rounds

    print(f"[*] Dataset: {config.dataset.name}")
    print(f"[*] Source: {config.dataset.catalog_source}")
    print(f"[*] Diagnostic Classes: {config.dataset.num_classes} ({', '.join(config.dataset.class_names)})")
    print(f"[*] Sampling Rate: {config.dataset.sampling_rate} Hz | ECG Leads: {config.dataset.num_leads}")
    print(f"[*] IoMT Edge Clients: {config.federated.num_clients} (Byzantine Ratio: {config.federated.byzantine_client_ratio * 100:.0f}%)")

    # Step 1: Initialize Data Pipeline
    print("\n[Step 1/5] Loading & Preprocessing Multimodal Biosignals...")
    t0 = time.time()
    dataset_mgr = ECGDatasetManager(dataset_name=dataset_key, num_samples_per_class=120, seed=config.random_seed)
    train_recs, val_recs, test_recs = dataset_mgr.get_train_val_test_splits()
    print(f"    -> Records: Train={len(train_recs)}, Val={len(val_recs)}, Test={len(test_recs)} in {time.time()-t0:.2f}s")

    # Step 2: Initialize Coordinator & Ledger
    print("\n[Step 2/5] Initializing Split-FedMeta Coordinator & DAG Ledger...")
    coordinator = FRDDABACoordinator(config=config, dataset_manager=dataset_mgr)

    # Step 3: Run Federated Meta-Learning Training Campaign
    print(f"\n[Step 3/5] Executing {num_rounds} Global Split-FedMeta Rounds with f-RDP & DAG Blockchain...")
    print(f"{'Round':>5} | {'Val Loss':>8} | {'Val Acc (%)':>11} | {'Approved':>8} | {'Byz Blk':>7} | {'Comm (KB)':>9} | {'Epsilon':>8}")
    print("-" * 75)

    for r in range(1, num_rounds + 1):
        summary = coordinator.execute_training_round(r)
        if r % 5 == 0 or r == 1 or r == num_rounds:
            print(
                f"{summary['round']:>5} | "
                f"{summary['val_loss']:>8.4f} | "
                f"{summary['val_acc']:>10.2f}% | "
                f"{summary['approved_clients_count']:>8} | "
                f"{summary['rejected_byzantine_count']:>7} | "
                f"{summary['round_communication_kb']:>9.1f} | "
                f"{summary['converted_epsilon']:>8.2f}"
            )

    # Step 4: Final Test Evaluation
    print("\n[Step 4/5] Evaluating Global Model on Independent Test Set...")
    test_loss, test_acc, test_probs, test_targets = coordinator.meta_learner.evaluate_task(
        coordinator.meta_learner.global_client_model, test_recs
    )
    print(f"    -> Test Accuracy: {test_acc:.2f}% | Test Cross-Entropy Loss: {test_loss:.4f}")

    # Step 5: Compute All 15 Required Benchmark Metrics
    print("\n[Step 5/5] Computing All 15 Clinical, Systems, Blockchain, and Privacy Metrics...")
    evaluator = MetricsEvaluator(num_classes=config.dataset.num_classes)
    dag_stats = coordinator.dag_ledger.calculate_metrics(duration_sec=30.0)

    # Calculate average edge energy
    total_energy = sum(node.cumulative_energy_joules for node in coordinator.edge_nodes.values())
    avg_edge_energy = total_energy / len(coordinator.edge_nodes)

    # Representative privacy leakage score
    sample_leakage = coordinator.edge_nodes[0].privacy_engine.compute_privacy_leakage_score()

    all_metrics = evaluator.evaluate_all_15_metrics(
        probs=test_probs,
        targets=test_targets,
        round_history=coordinator.round_history,
        dag_metrics=dag_stats,
        edge_energy_joules=avg_edge_energy,
        privacy_leakage_score=sample_leakage
    )

    # Generate Figures
    visualizer = BenchmarkVisualizer(output_dir=FIGURES_DIR)
    conv_plot = visualizer.plot_convergence(coordinator.round_history, dataset_key)
    roc_plot = visualizer.plot_roc_curves(config.dataset.class_names, dataset_key)

    print(f"\n[Generated Figures]")
    print(f"    -> Convergence Curve: {conv_plot}")
    print(f"    -> Multiclass ROC Curves: {roc_plot}")

    # Display Consolidated 15 Metrics Table
    print(f"\n{'='*75}")
    print(f"📊 CONSOLIDATED 15 BENCHMARK METRICS: {dataset_key.upper()}")
    print(f"{'='*75}")
    metric_labels = [
        ("1. Classification Accuracy", "1_classification_accuracy", "%"),
        ("2. Precision (Macro)", "2_precision", "%"),
        ("3. Recall / Sensitivity", "3_recall_sensitivity", "%"),
        ("4. Specificity", "4_specificity", "%"),
        ("5. F1-Score (Macro)", "5_f1_score", "%"),
        ("6. Area Under ROC Curve (AUC-ROC)", "6_auc_roc", "scalar [0-1]"),
        ("7. End-to-End Latency", "7_end_to_end_latency_ms", "ms"),
        ("8. Convergence Rounds", "8_convergence_rounds", "rounds"),
        ("8b. Convergence Time", "8_convergence_time_sec", "seconds"),
        ("9. Communication Overhead", "9_communication_overhead_kb_per_round", "KB/round"),
        ("10. Blockchain Throughput", "10_blockchain_throughput_tps", "TPS"),
        ("11. Blockchain Confirmation Latency", "11_blockchain_confirmation_latency_ms", "ms"),
        ("12. Energy Consumption", "12_energy_consumption_joules", "Joules"),
        ("12b. Energy Consumption", "12_energy_consumption_mwh", "mWh"),
        ("13. Privacy Leakage Score", "13_privacy_leakage_score", "index [0-1]"),
        ("14. Model Communication Cost", "14_model_communication_cost_mb", "MB (total)"),
        ("15. Healthcare Data Availability", "15_healthcare_data_availability_pct", "%"),
    ]

    for label, key, unit in metric_labels:
        val = all_metrics.get(key, "N/A")
        print(f"  {label:<38}: {val:>10} {unit}")
    print(f"{'='*75}\n")

    return all_metrics, coordinator.round_history


def main():
    """Executes the full benchmark across all three ECG datasets."""
    datasets = ["mit_bih", "ptb_xl", "chapman_shaoxing"]
    all_results = {}

    for dkey in datasets:
        metrics, history = run_single_dataset_pipeline(dkey, num_rounds=25)
        all_results[dkey] = {
            "metrics": metrics,
            "round_history": history,
        }

    # Save comprehensive results JSON
    out_file = os.path.join(RESULTS_DIR, "f_rdda_ba_results.json")
    with open(out_file, "w", encoding="utf-8") as f:
        json.dump(all_results, f, indent=2)

    print(f"\n[+] Master results successfully exported to: {out_file}")
    print("[+] All 3 datasets evaluated successfully!")


if __name__ == "__main__":
    main()
