"""
Edge Preprocessing & Physiological Feature Extraction Module
Performs baseline wander removal, noise filtering, missing-value imputation,
Z-score normalization, and temporal/morphological ECG feature extraction on edge devices.
"""

import math
from typing import List, Dict, Tuple, Any


class EdgeSignalPreprocessor:
    """
    Lightweight signal processing executed locally on edge microcontrollers.
    Designed for minimal memory and computational footprint.
    """

    def __init__(self, sampling_rate: int = 360):
        self.sampling_rate = sampling_rate

    def remove_baseline_wander(self, signal: List[float], window_sec: float = 0.20) -> List[float]:
        """
        Removes baseline wander using a lightweight moving-average highpass filter.
        y[n] = x[n] - moving_average(x, window)
        """
        half_win = max(1, int((window_sec * self.sampling_rate) / 2))
        n = len(signal)
        filtered = [0.0] * n

        # Running sum for O(N) moving average
        running_sum = 0.0
        for i in range(min(half_win, n)):
            running_sum += signal[i]

        for i in range(n):
            # Update running sum window
            start_idx = max(0, i - half_win)
            end_idx = min(n - 1, i + half_win)
            count = end_idx - start_idx + 1

            # Local mean
            sub_sum = sum(signal[start_idx : end_idx + 1])
            local_mean = sub_sum / count
            filtered[i] = round(signal[i] - local_mean, 5)

        return filtered

    def bandpass_denoise(self, signal: List[float]) -> List[float]:
        """
        Suppresses high-frequency EMG muscle artifacts and low-frequency motion.
        Implements a 3-point weighted smoothing filter:
        y[n] = 0.25 * x[n-1] + 0.5 * x[n] + 0.25 * x[n+1]
        """
        n = len(signal)
        if n < 3:
            return signal[:]

        denoised = [signal[0]] * n
        for i in range(1, n - 1):
            denoised[i] = round(0.25 * signal[i - 1] + 0.50 * signal[i] + 0.25 * signal[i + 1], 5)
        denoised[n - 1] = signal[n - 1]
        return denoised

    def zscore_normalize(self, signal: List[float]) -> List[float]:
        """
        Applies standard Z-score normalization per lead: (x - mean) / (std + eps).
        """
        n = len(signal)
        if n == 0:
            return []

        mean_val = sum(signal) / n
        variance = sum((x - mean_val) ** 2 for x in signal) / n
        std_val = math.sqrt(variance)

        eps = 1e-6
        return [round((x - mean_val) / (std_val + eps), 5) for x in signal]

    def impute_missing_vitals(self, vitals: Dict[str, float]) -> Dict[str, float]:
        """
        Imputes missing vital sign telemetry values using physiological nominal defaults.
        """
        nominal_defaults = {
            "heart_rate": 75.0,
            "sbp": 120.0,
            "dbp": 80.0,
            "spo2": 98.0,
            "temperature": 37.0,
        }
        imputed = {}
        for key, default_val in nominal_defaults.items():
            val = vitals.get(key)
            if val is None or math.isnan(val) or val <= 0:
                imputed[key] = default_val
            else:
                imputed[key] = float(val)
        return imputed

    def detect_r_peaks(self, lead_signal: List[float]) -> List[int]:
        """
        Detects R-peaks using lightweight adaptive thresholding (Pan-Tompkins variant).
        """
        n = len(lead_signal)
        if n < 5:
            return []

        # Squaring to emphasize large QRS complexes
        squared = [x ** 2 for x in lead_signal]
        mean_power = sum(squared) / n
        threshold = 2.2 * mean_power

        min_distance = int(0.20 * self.sampling_rate)  # Minimum 200 ms between heartbeats (refractory period)
        peaks = []
        last_peak = -min_distance

        for i in range(1, n - 1):
            if squared[i] > threshold and squared[i] > squared[i - 1] and squared[i] > squared[i + 1]:
                if (i - last_peak) >= min_distance:
                    peaks.append(i)
                    last_peak = i

        return peaks

    def extract_morphological_features(self, multilead_ecg: List[List[float]], vitals: Dict[str, float]) -> List[float]:
        """
        Extracts compact, clinically informative physiological feature vector for edge inference:
        - R-peak count and mean RR interval
        - Heart Rate Variability (SDNN)
        - QRS amplitude and energy across leads
        - ST segment deflection
        - Synchronized vital signs (HR, SBP, DBP, SpO2, Temp)
        """
        features: List[float] = []

        # Analyze primary diagnostic lead (Lead I or II)
        lead2 = multilead_ecg[min(1, len(multilead_ecg) - 1)]
        peaks = self.detect_r_peaks(lead2)

        # RR Interval features
        if len(peaks) >= 2:
            rr_intervals = [(peaks[i] - peaks[i - 1]) / self.sampling_rate for i in range(1, len(peaks))]
            mean_rr = sum(rr_intervals) / len(rr_intervals)
            sdnn = math.sqrt(sum((r - mean_rr) ** 2 for r in rr_intervals) / len(rr_intervals))
        else:
            mean_rr = 0.80  # Default nominal RR (75 bpm)
            sdnn = 0.04

        features.extend([round(mean_rr, 4), round(sdnn, 4)])

        # Morphological amplitude features across available leads (up to first 6 leads)
        for lead_idx in range(min(6, len(multilead_ecg))):
            lead = multilead_ecg[lead_idx]
            max_amp = max(lead) if lead else 0.0
            min_amp = min(lead) if lead else 0.0
            p2p_amp = max_amp - min_amp
            rms_energy = math.sqrt(sum(x ** 2 for x in lead) / max(1, len(lead)))
            features.extend([round(p2p_amp, 4), round(rms_energy, 4)])

        # ST Segment deflection at 80 ms past central R peak
        st_deflection = 0.0
        if peaks:
            r_idx = peaks[0]
            st_idx = min(len(lead2) - 1, r_idx + int(0.08 * self.sampling_rate))
            st_deflection = lead2[st_idx]
        features.append(round(st_deflection, 4))

        # Synchronized Vital Signs (Normalized)
        clean_vitals = self.impute_missing_vitals(vitals)
        norm_hr = (clean_vitals["heart_rate"] - 75.0) / 30.0
        norm_sbp = (clean_vitals["sbp"] - 120.0) / 25.0
        norm_dbp = (clean_vitals["dbp"] - 80.0) / 15.0
        norm_spo2 = (clean_vitals["spo2"] - 98.0) / 3.0
        norm_temp = (clean_vitals["temperature"] - 37.0) / 1.0

        features.extend([
            round(norm_hr, 4),
            round(norm_sbp, 4),
            round(norm_dbp, 4),
            round(norm_spo2, 4),
            round(norm_temp, 4),
        ])

        return features

    def preprocess_record(self, raw_record: Dict[str, Any]) -> Dict[str, Any]:
        """
        Executes full preprocessing pipeline on a multi-sensor patient record.
        """
        raw_signals = raw_record["ecg_signal"]
        clean_signals = []

        for lead_sig in raw_signals:
            no_wander = self.remove_baseline_wander(lead_sig)
            denoised = self.bandpass_denoise(no_wander)
            normalized = self.zscore_normalize(denoised)
            clean_signals.append(normalized)

        clean_vitals = self.impute_missing_vitals(raw_record.get("vital_signs", {}))
        extracted_features = self.extract_morphological_features(clean_signals, clean_vitals)

        return {
            "dataset": raw_record["dataset"],
            "class_index": raw_record["class_index"],
            "class_name": raw_record["class_name"],
            "clean_signals": clean_signals,
            "clean_vitals": clean_vitals,
            "feature_vector": extracted_features,
        }
