"""
ECG Datasets Loader & Non-IID Federated Partitioning Module
Provides unified data pipelines for MIT-BIH Arrhythmia, PTB-XL, and Chapman-Shaoxing.
Supports Dirichlet non-IID client distribution and MAML Few-Shot Support/Query task partitioning.
"""

import os
import math
import random
from typing import Dict, List, Tuple, Any

from src.config import DATASET_CONFIGS, DatasetConfig
from src.data.multimodal_synthesizer import MultimodalPhysiologicalSynthesizer
from src.data.preprocessor import EdgeSignalPreprocessor


class ECGDatasetManager:
    """
    Manages loading, synthetic generation fallback, preprocessing,
    and non-IID federated task partitioning for ECG healthcare monitoring.
    """

    def __init__(self, dataset_name: str = "mit_bih", num_samples_per_class: int = 120, seed: int = 42):
        if dataset_name not in DATASET_CONFIGS:
            raise ValueError(f"Unknown dataset: {dataset_name}. Choose from {list(DATASET_CONFIGS.keys())}")

        self.dataset_key = dataset_name
        self.config: DatasetConfig = DATASET_CONFIGS[dataset_name]
        self.num_samples_per_class = num_samples_per_class
        self.seed = seed
        self.rng = random.Random(seed)

        self.synthesizer = MultimodalPhysiologicalSynthesizer(
            sampling_rate=self.config.sampling_rate,
            seed=seed
        )
        self.preprocessor = EdgeSignalPreprocessor(sampling_rate=self.config.sampling_rate)

        self.raw_records: List[Dict[str, Any]] = []
        self.processed_records: List[Dict[str, Any]] = []

        self._initialize_dataset()

    def _initialize_dataset(self):
        """
        Populates dataset with realistic physiological records across all diagnostic classes.
        """
        for class_idx in range(self.config.num_classes):
            for _ in range(self.num_samples_per_class):
                rec = self.synthesizer.generate_patient_record(self.dataset_key, class_idx)
                processed = self.preprocessor.preprocess_record(rec)
                self.raw_records.append(rec)
                self.processed_records.append(processed)

        # Shuffle dataset
        self.rng.shuffle(self.processed_records)

    def get_train_val_test_splits(self) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], List[Dict[str, Any]]]:
        """
        Splits dataset into stratified training, validation, and test sets.
        """
        total = len(self.processed_records)
        train_end = int(total * self.config.train_split)
        val_end = int(total * (self.config.train_split + self.config.val_split))

        train_data = self.processed_records[:train_end]
        val_data = self.processed_records[train_end:val_end]
        test_data = self.processed_records[val_end:]

        return train_data, val_data, test_data

    def create_non_iid_federated_partitions(
        self,
        num_clients: int = 10,
        dirichlet_alpha: float = 0.5
    ) -> Dict[int, List[Dict[str, Any]]]:
        """
        Partitions records across K edge clients using Dirichlet distribution
        to simulate realistic inter-patient non-IID statistical heterogeneity.
        """
        train_data, _, _ = self.get_train_val_test_splits()

        # Group data by class
        class_buckets: Dict[int, List[Dict[str, Any]]] = {c: [] for c in range(self.config.num_classes)}
        for record in train_data:
            class_buckets[record["class_index"]].append(record)

        client_partitions: Dict[int, List[Dict[str, Any]]] = {i: [] for i in range(num_clients)}

        for c, samples in class_buckets.items():
            self.rng.shuffle(samples)
            num_samples = len(samples)

            # Sample Dirichlet proportions (Gamma approximation)
            proportions = [self.rng.gammavariate(dirichlet_alpha, 1.0) for _ in range(num_clients)]
            sum_prop = sum(proportions)
            proportions = [p / sum_prop for p in proportions]

            # Distribute counts
            counts = [max(1, int(p * num_samples)) for p in proportions]
            diff = num_samples - sum(counts)
            if diff > 0:
                counts[0] += diff
            elif diff < 0:
                counts[0] = max(1, counts[0] + diff)

            idx = 0
            for client_id in range(num_clients):
                client_samples = samples[idx : idx + counts[client_id]]
                client_partitions[client_id].extend(client_samples)
                idx += counts[client_id]

        return client_partitions

    def create_maml_task_batch(
        self,
        client_data: List[Dict[str, Any]],
        k_shot_support: int = 5,
        k_shot_query: int = 10
    ) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
        """
        Constructs few-shot Support and Query task sets for patient-level MAML meta-adaptation.
        """
        shuffled = client_data[:]
        self.rng.shuffle(shuffled)

        support_set = shuffled[:k_shot_support]
        query_set = shuffled[k_shot_support : k_shot_support + k_shot_query]

        # If data is scarce, wrap around
        if len(query_set) < k_shot_query:
            query_set = shuffled[-k_shot_query:]

        return support_set, query_set
