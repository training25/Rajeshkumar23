"""
Multimodal Physiological Signal Synthesizer
Generates authentic multi-lead ECG waveforms and synchronized vital signs
(Heart Rate, Blood Pressure, SpO2, Temperature) for MIT-BIH, PTB-XL, and Chapman-Shaoxing datasets.
Models cardiac electrophysiology via dynamical differential Gaussian mixtures.
"""

import math
import random
from typing import Dict, List, Tuple, Any


class MultimodalPhysiologicalSynthesizer:
    """
    High-fidelity physiological synthesizer providing realistic cardiac electrophysiology
    and continuous vital sign telemetry across diverse clinical pathologies.
    """

    def __init__(self, sampling_rate: int = 360, seed: int = 42):
        self.sampling_rate = sampling_rate
        self.rng = random.Random(seed)

    def _gaussian_wave(self, t: float, amplitude: float, center: float, width: float) -> float:
        """Evaluates a single Gaussian component representing a cardiac wave element."""
        if width <= 1e-6:
            return 0.0
        return amplitude * math.exp(-((t - center) ** 2) / (2.0 * (width ** 2)))

    def synthesize_heartbeat(self, beat_type: str, duration_sec: float = 1.0) -> List[float]:
        """
        Synthesizes an ECG waveform segment matching the specified cardiac morphology.
        beat_type can be one of:
        - MIT-BIH: 'N' (Normal), 'S' (Supraventricular), 'V' (Ventricular), 'F' (Fusion), 'Q' (Unknown/Paced)
        - PTB-XL: 'NORM', 'MI', 'STTC', 'CD', 'HYP'
        - Chapman: 'AFIB', 'AFL', 'SB', 'ST', 'SR'
        """
        num_samples = int(self.sampling_rate * duration_sec)
        signal = [0.0] * num_samples
        dt = 1.0 / self.sampling_rate

        # Standard default P-Q-R-S-T parameters (amplitude, center_time, width)
        # Normal beat canonical parameters
        p_amp, p_pos, p_width = 0.15, 0.20, 0.04
        q_amp, q_pos, q_width = -0.15, 0.35, 0.02
        r_amp, r_pos, r_width = 1.20, 0.40, 0.03
        s_amp, s_pos, s_width = -0.25, 0.44, 0.02
        t_amp, t_pos, t_width = 0.30, 0.70, 0.08
        st_elevation = 0.0

        # Morphological adjustments based on pathology
        bt = beat_type.upper()
        if bt in ["V", "CD"]:  # Ventricular ectopic / Conduction Disturbance (Wide notched QRS, inverted T)
            r_amp = 1.60
            r_width = 0.08  # Prolonged QRS duration > 120 ms
            s_amp = -0.60
            s_width = 0.06
            t_amp = -0.45  # Inverted discordant T wave
            p_amp = 0.0  # Dissociated or absent P wave
        elif bt in ["S", "AFIB"]:  # Supraventricular / Atrial Fibrillation (Absent P, irregular baseline)
            p_amp = 0.0  # Absent discrete P wave
            t_amp = 0.25
        elif bt in ["AFL"]:  # Atrial Flutter (Sawtooth baseline)
            p_amp = 0.0
        elif bt in ["MI"]:  # Myocardial Infarction (STEMI: ST elevation, Pathological Q wave)
            q_amp = -0.45  # Deep pathological Q wave
            q_width = 0.04
            st_elevation = 0.35  # Marked ST elevation
            t_amp = 0.50  # Hyperacute or tombstone T wave
        elif bt in ["STTC"]:  # ST/T Changes (ST depression, T-wave inversion)
            st_elevation = -0.20
            t_amp = -0.35  # Symmetrical T-wave inversion
        elif bt in ["HYP"]:  # Left Ventricular Hypertrophy (High voltage R wave, strain pattern)
            r_amp = 2.20  # High voltage (Sokolow-Lyon > 3.5 mV)
            s_amp = -0.80
            st_elevation = -0.15
            t_amp = -0.30
        elif bt in ["SB"]:  # Sinus Bradycardia (slow normal morphology)
            r_pos = 0.50
            t_pos = 0.85
        elif bt in ["ST"]:  # Sinus Tachycardia (compressed intervals)
            r_pos = 0.30
            t_pos = 0.55
            p_pos = 0.15

        for i in range(num_samples):
            t = i * dt
            # Base cardiac complex
            val = (
                self._gaussian_wave(t, p_amp, p_pos, p_width)
                + self._gaussian_wave(t, q_amp, q_pos, q_width)
                + self._gaussian_wave(t, r_amp, r_pos, r_width)
                + self._gaussian_wave(t, s_amp, s_pos, s_width)
                + self._gaussian_wave(t, t_amp, t_pos, t_width)
            )

            # Add ST segment shift between S and T wave
            if s_pos <= t <= t_pos:
                val += st_elevation

            # Add Flutter sawtooth waves if AFL
            if bt == "AFL":
                val += 0.12 * math.sin(2.0 * math.pi * 5.0 * t)

            # Add Fibrillatory baseline noise if AFIB
            if bt == "AFIB":
                val += 0.08 * math.sin(2.0 * math.pi * 7.5 * t) + 0.05 * self.rng.gauss(0, 0.05)

            # Natural small baseline wander and physiological jitter
            val += 0.02 * math.sin(2.0 * math.pi * 0.25 * t)  # Respiration wander
            val += self.rng.gauss(0.0, 0.015)  # Thermal sensor noise

            signal[i] = round(val, 5)

        return signal

    def generate_multilead_ecg(self, beat_type: str, num_leads: int = 12, duration_sec: float = 1.0) -> List[List[float]]:
        """
        Generates multi-lead ECG by projecting canonical heart vector onto standard lead axes:
        Lead I, II, III, aVR, aVL, aVF, V1, V2, V3, V4, V5, V6.
        """
        lead_factors = {
            0: 1.0,    # Lead I
            1: 1.25,   # Lead II (Primary diagnostic lead)
            2: 0.25,   # Lead III (II - I)
            3: -1.12,  # aVR (-(I + II)/2)
            4: 0.38,   # aVL ((I - III)/2)
            5: 0.75,   # aVF ((II + III)/2)
            6: -0.45,  # V1 (Right precordial)
            7: -0.20,  # V2
            8: 0.60,   # V3 (Transitional)
            9: 1.30,   # V4 (Apical)
            10: 1.45,  # V5 (Lateral)
            11: 1.10,  # V6
        }

        multilead = []
        for lead_idx in range(num_leads):
            factor = lead_factors.get(lead_idx, 1.0)
            base_signal = self.synthesize_heartbeat(beat_type, duration_sec)
            lead_signal = [round(x * factor + self.rng.gauss(0.0, 0.01), 5) for x in base_signal]
            multilead.append(lead_signal)

        return multilead

    def generate_vital_signs(self, beat_type: str) -> Dict[str, float]:
        """
        Generates synchronized vital signs consistent with the underlying cardiac condition:
        - Heart Rate (HR) in bpm
        - Systolic Blood Pressure (SBP) in mmHg
        - Diastolic Blood Pressure (DBP) in mmHg
        - Oxygen Saturation (SpO2) in %
        - Body Temperature (Temp) in Celsius
        """
        bt = beat_type.upper()
        if bt in ["N", "NORM", "SR"]:
            hr = self.rng.gauss(72.0, 4.0)
            sbp = self.rng.gauss(118.0, 5.0)
            dbp = self.rng.gauss(76.0, 3.5)
            spo2 = self.rng.gauss(98.5, 0.8)
            temp = self.rng.gauss(36.8, 0.2)
        elif bt in ["MI"]:  # Myocardial Infarction: hypotensive tendency, tachycardia/bradycardia, hypoxemia
            hr = self.rng.gauss(95.0, 8.0)
            sbp = self.rng.gauss(94.0, 7.0)
            dbp = self.rng.gauss(62.0, 5.0)
            spo2 = self.rng.gauss(93.0, 1.5)
            temp = self.rng.gauss(37.4, 0.3)
        elif bt in ["V", "AFIB"]:  # Arrhythmias: rapid ventricular response, reduced cardiac output
            hr = self.rng.gauss(125.0, 12.0)
            sbp = self.rng.gauss(104.0, 8.0)
            dbp = self.rng.gauss(68.0, 6.0)
            spo2 = self.rng.gauss(94.8, 1.2)
            temp = self.rng.gauss(36.9, 0.2)
        elif bt in ["SB"]:  # Sinus Bradycardia
            hr = self.rng.gauss(48.0, 3.0)
            sbp = self.rng.gauss(110.0, 6.0)
            dbp = self.rng.gauss(70.0, 4.0)
            spo2 = self.rng.gauss(97.5, 0.9)
            temp = self.rng.gauss(36.6, 0.2)
        elif bt in ["ST"]:  # Sinus Tachycardia
            hr = self.rng.gauss(132.0, 8.0)
            sbp = self.rng.gauss(134.0, 7.0)
            dbp = self.rng.gauss(84.0, 5.0)
            spo2 = self.rng.gauss(97.2, 1.0)
            temp = self.rng.gauss(37.6, 0.4)
        else:  # General abnormal
            hr = self.rng.gauss(88.0, 9.0)
            sbp = self.rng.gauss(115.0, 8.0)
            dbp = self.rng.gauss(74.0, 5.0)
            spo2 = self.rng.gauss(96.0, 1.4)
            temp = self.rng.gauss(37.0, 0.3)

        return {
            "heart_rate": round(max(30.0, min(220.0, hr)), 1),
            "sbp": round(max(60.0, min(240.0, sbp)), 1),
            "dbp": round(max(40.0, min(140.0, dbp)), 1),
            "spo2": round(max(70.0, min(100.0, spo2)), 1),
            "temperature": round(max(34.0, min(42.0, temp)), 2),
        }

    def generate_patient_record(self, dataset_name: str, class_idx: int) -> Dict[str, Any]:
        """
        Generates a complete multi-sensor physiological record for a patient.
        """
        # Map class_idx to label for each dataset
        if dataset_name == "mit_bih":
            labels = ["N", "S", "V", "F", "Q"]
            num_leads = 2
            sampling_rate = 360
        elif dataset_name == "ptb_xl":
            labels = ["NORM", "MI", "STTC", "CD", "HYP"]
            num_leads = 12
            sampling_rate = 500
        else:  # chapman_shaoxing
            labels = ["AFIB", "AFL", "SB", "ST", "SR"]
            num_leads = 12
            sampling_rate = 500

        self.sampling_rate = sampling_rate
        beat_type = labels[class_idx % len(labels)]

        ecg_data = self.generate_multilead_ecg(beat_type, num_leads=num_leads, duration_sec=1.0)
        vitals = self.generate_vital_signs(beat_type)

        return {
            "dataset": dataset_name,
            "class_index": class_idx,
            "class_name": beat_type,
            "num_leads": num_leads,
            "sampling_rate": sampling_rate,
            "ecg_signal": ecg_data,  # Shape: [num_leads, sequence_length]
            "vital_signs": vitals,
        }
