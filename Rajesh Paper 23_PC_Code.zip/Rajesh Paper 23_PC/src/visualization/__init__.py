"""
Visualization module initialization.
"""
from src.visualization.plotter import BenchmarkVisualizer

__all__ = ["BenchmarkVisualizer"]
