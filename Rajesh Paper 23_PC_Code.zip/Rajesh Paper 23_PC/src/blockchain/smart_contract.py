"""
Smart Contract Validator & Autonomous Verification Engine
Enforces cryptographic client authentication, privacy compliance,
freshness checks, and stake-weighted gradient deviation validation on the DAG ledger.
"""

import time
import hashlib
from typing import Dict, List, Tuple, Any

from src.blockchain.dag_ledger import LightweightDAGLedger, DAGTransaction
from src.blockchain.stake_gradient_deviation import StakeWeightedDeviationDefense


class SmartContractValidator:
    """
    Simulates on-chain smart contract execution.
    Audits incoming model updates, ensures zero data leakage, and records validated DAG blocks.
    """

    def __init__(
        self,
        dag_ledger: LightweightDAGLedger,
        stake_defense: StakeWeightedDeviationDefense,
        max_epsilon: float = 4.0,
        max_skew_sec: float = 10.0
    ):
        self.ledger = dag_ledger
        self.stake_defense = stake_defense
        self.max_epsilon = max_epsilon
        self.max_skew_sec = max_skew_sec

        self.rejection_log: List[Dict[str, Any]] = []
        self.validation_history: List[Dict[str, Any]] = []

    def _verify_signature(self, client_id: int, model_hash: str, signature: str) -> bool:
        """Verifies cryptographic signature matching the client's public identity."""
        expected_sig = hashlib.sha256(f"CLIENT_{client_id}_{model_hash}".encode("utf-8")).hexdigest()[:16]
        return signature == expected_sig

    def validate_and_commit_update(
        self,
        client_id: int,
        round_num: int,
        model_hash: str,
        rdp_epsilon: float,
        gradient_vector: List[float],
        signature: str,
        timestamp: float = None
    ) -> Tuple[bool, Optional[DAGTransaction], str]:
        """
        Executes smart contract rule checklist:
        1. Timestamp freshness
        2. Cryptographic signature check
        3. Privacy budget compliance
        4. Minimum stake check
        Returns: (is_valid, dag_transaction_receipt, status_message).
        """
        curr_time = time.time()
        tx_time = timestamp if timestamp is not None else curr_time

        # Rule 1: Freshness verification
        if abs(curr_time - tx_time) > self.max_skew_sec:
            msg = f"Rejected: Stale timestamp (skew: {abs(curr_time - tx_time):.2f}s > {self.max_skew_sec}s)"
            self.rejection_log.append({"client_id": client_id, "reason": msg, "round": round_num})
            return False, None, msg

        # Rule 2: Signature verification
        if not self._verify_signature(client_id, model_hash, signature):
            msg = "Rejected: Invalid cryptographic signature (unauthorized client)"
            self.rejection_log.append({"client_id": client_id, "reason": msg, "round": round_num})
            return False, None, msg

        # Rule 3: Privacy budget check
        if rdp_epsilon > self.max_epsilon:
            msg = f"Rejected: Privacy budget exhausted ({rdp_epsilon:.3f} > {self.max_epsilon})"
            self.rejection_log.append({"client_id": client_id, "reason": msg, "round": round_num})
            return False, None, msg

        # Rule 4: Minimum stake check
        client_stake = self.stake_defense.client_stakes.get(client_id, 0.0)
        if client_stake < self.stake_defense.min_stake:
            msg = f"Rejected: Insufficient client stake ({client_stake:.3f} < {self.stake_defense.min_stake})"
            self.rejection_log.append({"client_id": client_id, "reason": msg, "round": round_num})
            return False, None, msg

        # All contract checks passed; commit transaction metadata to the DAG ledger
        tx_receipt = self.ledger.add_transaction(
            client_id=client_id,
            round_num=round_num,
            model_hash=model_hash,
            rdp_epsilon=rdp_epsilon,
            stake_weight=client_stake,
            signature=signature
        )

        record = {
            "tx_id": tx_receipt.tx_id,
            "client_id": client_id,
            "round_num": round_num,
            "status": "APPROVED_ON_CHAIN",
            "confirmation_latency_ms": tx_receipt.confirmation_time_ms,
        }
        self.validation_history.append(record)

        return True, tx_receipt, "SUCCESS_VALIDATED_ON_CHAIN"
