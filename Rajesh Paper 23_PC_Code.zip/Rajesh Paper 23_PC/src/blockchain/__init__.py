"""
Blockchain module initialization.
"""
from src.blockchain.dag_ledger import LightweightDAGLedger, DAGTransaction
from src.blockchain.stake_gradient_deviation import StakeWeightedDeviationDefense
from src.blockchain.smart_contract import SmartContractValidator

__all__ = [
    "LightweightDAGLedger",
    "DAGTransaction",
    "StakeWeightedDeviationDefense",
    "SmartContractValidator",
]
