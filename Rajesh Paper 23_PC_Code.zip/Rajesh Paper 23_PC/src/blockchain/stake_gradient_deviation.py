"""
Stake-Weighted Gradient Deviation & Byzantine Defense Protocol
Evaluates client model-update consistency, computes multi-dimensional gradient deviations,
enforces dynamic stake-adaptive anomaly thresholds, and slashes malicious node stakes.
"""

import math
from typing import List, Dict, Tuple, Any

from src.config import StakeWeightedDeviationConfig


class StakeWeightedDeviationDefense:
    """
    Byzantine-robust aggregation defense.
    Filters poisoned or malicious updates using stake-weighted Euclidean and Cosine gradient deviations.
    """

    def __init__(
        self,
        num_clients: int = 10,
        gamma_multiplier: float = 1.5,
        cosine_threshold: float = 0.45,
        slashing_penalty: float = 0.25,
        reputation_reward: float = 0.08,
        min_stake: float = 0.10
    ):
        self.num_clients = num_clients
        self.gamma = gamma_multiplier
        self.cosine_threshold = cosine_threshold
        self.slashing_penalty = slashing_penalty
        self.reputation_reward = reputation_reward
        self.min_stake = min_stake

        # Initialize stakes uniformly to 1.0
        self.client_stakes: Dict[int, float] = {i: 1.0 for i in range(num_clients)}

    def compute_stake_weighted_mean(self, client_gradients: Dict[int, List[float]]) -> List[float]:
        """
        Calculates stake-weighted mean gradient vector:
        g_bar = sum(w_k * g_k) / sum(w_k).
        """
        if not client_gradients:
            return []

        grad_dim = len(next(iter(client_gradients.values())))
        total_stake = sum(self.client_stakes[cid] for cid in client_gradients.keys())
        if total_stake <= 1e-9:
            total_stake = 1.0

        mean_grad = [0.0] * grad_dim
        for cid, grad in client_gradients.items():
            norm_w = self.client_stakes[cid] / total_stake
            for i in range(grad_dim):
                mean_grad[i] += norm_w * grad[i]

        return [round(x, 6) for x in mean_grad]

    def _l2_norm(self, vec: List[float]) -> float:
        return math.sqrt(sum(x ** 2 for x in vec))

    def _cosine_distance(self, vec1: List[float], vec2: List[float]) -> float:
        norm1 = self._l2_norm(vec1)
        norm2 = self._l2_norm(vec2)
        if norm1 <= 1e-12 or norm2 <= 1e-12:
            return 1.0

        dot = sum(a * b for a, b in zip(vec1, vec2))
        cos_sim = max(-1.0, min(1.0, dot / (norm1 * norm2)))
        return 1.0 - cos_sim

    def evaluate_updates(
        self,
        client_gradients: Dict[int, List[float]]
    ) -> Tuple[Dict[int, bool], List[float], Dict[str, Any]]:
        """
        Evaluates each submitted client gradient update against stake-weighted deviation thresholds:
        D_k = ||g_k - g_bar||_2
        tau_k = mu_D + gamma * (sigma_D / sqrt(s_k))
        C_k = 1 - cos(g_k, g_bar) <= cosine_threshold

        Returns: (client_accepted_dict, aggregated_mean_grad, evaluation_stats).
        """
        if not client_gradients:
            return {}, [], {}

        # 1. Compute tentative stake-weighted mean
        g_bar = self.compute_stake_weighted_mean(client_gradients)

        # 2. Compute Euclidean and Cosine deviations
        euclidean_devs: Dict[int, float] = {}
        cosine_devs: Dict[int, float] = {}

        for cid, grad in client_gradients.items():
            diff = [g - b for g, b in zip(grad, g_bar)]
            euclidean_devs[cid] = self._l2_norm(diff)
            cosine_devs[cid] = self._cosine_distance(grad, g_bar)

        # 3. Dynamic Threshold Calculation
        all_d = list(euclidean_devs.values())
        mu_d = sum(all_d) / len(all_d)
        var_d = sum((d - mu_d) ** 2 for d in all_d) / len(all_d)
        sigma_d = math.sqrt(var_d)

        accepted_clients: Dict[int, bool] = {}
        rejected_cids: List[int] = []
        approved_cids: List[int] = []

        for cid, grad in client_gradients.items():
            s_k = max(self.min_stake, self.client_stakes[cid])
            tau_k = mu_d + self.gamma * (sigma_d / math.sqrt(s_k))

            d_val = euclidean_devs[cid]
            c_val = cosine_devs[cid]

            # Rejection logic
            if (d_val > tau_k and len(client_gradients) > 3) or (c_val > self.cosine_threshold):
                accepted_clients[cid] = False
                rejected_cids.append(cid)
                # Slash stake
                self.client_stakes[cid] = round(max(self.min_stake, self.client_stakes[cid] * (1.0 - self.slashing_penalty)), 4)
            else:
                accepted_clients[cid] = True
                approved_cids.append(cid)
                # Reward stake
                self.client_stakes[cid] = round(min(1.0, self.client_stakes[cid] + self.reputation_reward), 4)

        # 4. Final Aggregated Gradient (Computed only over approved clients)
        approved_grads = {cid: client_gradients[cid] for cid in approved_cids}
        if not approved_grads:
            # Fallback if all rejected (emergency fallback)
            approved_grads = client_gradients

        final_aggregated_grad = self.compute_stake_weighted_mean(approved_grads)

        stats = {
            "num_submitted": len(client_gradients),
            "num_approved": len(approved_cids),
            "num_rejected": len(rejected_cids),
            "rejected_client_ids": rejected_cids,
            "mean_euclidean_dev": round(mu_d, 4),
            "sigma_euclidean_dev": round(sigma_d, 4),
            "stakes_summary": {cid: self.client_stakes[cid] for cid in client_gradients.keys()},
        }

        return accepted_clients, final_aggregated_grad, stats
