"""
Metrics module initialization.
"""
from src.metrics.evaluator import MetricsEvaluator

__all__ = ["MetricsEvaluator"]
