"""
Configuration Module for f-RDDA-BA Framework
Defines all global hyperparameters, network topologies, dataset specifications,
blockchain consensus parameters, and differential privacy settings.
"""

import os
from dataclasses import dataclass, field
from typing import List, Dict, Any

# Root Paths
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")
RESULTS_DIR = os.path.join(BASE_DIR, "results")
FIGURES_DIR = os.path.join(RESULTS_DIR, "figures")
LOGS_DIR = os.path.join(RESULTS_DIR, "logs")

# Ensure required output directories exist
for d in [DATA_DIR, RESULTS_DIR, FIGURES_DIR, LOGS_DIR]:
    os.makedirs(d, exist_ok=True)


@dataclass
class DatasetConfig:
    name: str
    catalog_source: str
    num_classes: int
    class_names: List[str]
    sampling_rate: int  # in Hz
    sequence_length: int  # number of time samples
    num_leads: int  # ECG leads (e.g., 2 for MIT-BIH, 12 for PTB-XL & Chapman)
    telemetry_channels: int = 5  # Vital signs: HR, BP Systolic, BP Diastolic, SpO2, Temp
    train_split: float = 0.70
    val_split: float = 0.15
    test_split: float = 0.15


# 3 Selected Benchmark Datasets from vlbthambawita/ECGDatasets
DATASET_CONFIGS: Dict[str, DatasetConfig] = {
    "mit_bih": DatasetConfig(
        name="MIT-BIH Arrhythmia Database",
        catalog_source="https://github.com/vlbthambawita/ECGDatasets (PhysioNet)",
        num_classes=5,
        class_names=["Normal (N)", "Supraventricular (S)", "Ventricular (V)", "Fusion (F)", "Unknown (Q)"],
        sampling_rate=360,
        sequence_length=360,  # 1-second segment
        num_leads=2,
    ),
    "ptb_xl": DatasetConfig(
        name="PTB-XL 12-Lead ECG Database",
        catalog_source="https://github.com/vlbthambawita/ECGDatasets (PhysioNet / Physikalisch-Technische)",
        num_classes=5,
        class_names=["NORM (Normal)", "MI (Myocardial Infarction)", "STTC (ST/T Change)", "CD (Conduction Disturbance)", "HYP (Hypertrophy)"],
        sampling_rate=500,
        sequence_length=500,  # 1-second segment (or 10s downsampled)
        num_leads=12,
    ),
    "chapman_shaoxing": DatasetConfig(
        name="Chapman-Shaoxing & Ningbo Database",
        catalog_source="https://github.com/vlbthambawita/ECGDatasets (Chapman University & Shaoxing)",
        num_classes=5,
        class_names=["AFIB (Atrial Fib)", "AFL (Atrial Flutter)", "SB (Sinus Brady)", "ST (Sinus Tachy)", "SR (Sinus Rhythm)"],
        sampling_rate=500,
        sequence_length=500,
        num_leads=12,
    ),
}


@dataclass
class ModelConfig:
    client_cut_dim: int = 64  # Output dimension of edge cut layer (smashed data representation)
    conv1d_filters: List[int] = field(default_factory=lambda: [32, 64])
    kernel_sizes: List[int] = field(default_factory=lambda: [7, 5])
    server_lstm_units: int = 128
    dropout_rate: float = 0.25
    fc_hidden_dim: int = 64


@dataclass
class FederatedMetaConfig:
    num_clients: int = 10
    active_clients_per_round: int = 8
    num_global_rounds: int = 25
    inner_learning_rate: float = 0.01  # alpha for local fast adaptation (MAML)
    outer_learning_rate: float = 0.005  # beta for meta-update
    inner_adaptation_steps: int = 3  # k-shot adaptation steps
    batch_size: int = 16
    byzantine_client_ratio: float = 0.20  # 20% simulated adversarial/poisoning nodes
    attack_types: List[str] = field(default_factory=lambda: ["targeted_flip", "gaussian_noise", "sign_inversion"])


@dataclass
class FRDPConfig:
    """f-Divergence Renyi Differential Privacy (f-RDP) Configuration"""
    renyi_alpha: float = 4.0  # Order of Renyi divergence alpha > 1
    target_delta: float = 1e-5  # delta privacy parameter
    l2_clipping_threshold: float = 1.0  # S_g gradient sensitivity clipping bound
    noise_multiplier_sigma: float = 0.85  # Gaussian noise scale
    max_privacy_budget_epsilon: float = 4.0  # Upper bound on cumulative epsilon


@dataclass
class DAGBlockchainConfig:
    """Lightweight Directed Acyclic Graph (DAG) Ledger Configuration"""
    mcmc_lambda: float = 0.05  # Selection weight parameter for MCMC random walk
    num_parent_tips: int = 2  # Number of tips validated per new transaction
    max_timestamp_skew_ms: int = 5000  # Maximum acceptable transaction timestamp skew
    smart_contract_enabled: bool = True
    stake_slashing_penalty: float = 0.25  # Fraction of stake slashed upon malicious update detection
    minimum_valid_stake: float = 0.10  # Minimum stake required to submit updates
    target_throughput_tps: int = 350


@dataclass
class StakeWeightedDeviationConfig:
    """Stake-Weighted Gradient Deviation Anomaly Defense"""
    gamma_multiplier: float = 1.5  # Dynamic threshold scale factor
    cosine_threshold: float = 0.45  # Max allowable cosine divergence from stake-weighted mean
    reputation_decay: float = 0.05  # Natural stake decay per round
    reputation_reward: float = 0.08  # Stake increment upon verified honest contribution


@dataclass
class EdgeEnergyLatencyConfig:
    """Edge Hardware Energy and Latency Simulation Parameters (Wearable IoMT Specs)"""
    mcu_compute_power_mw: float = 45.0  # 45 mW active ARM Cortex-M4 / ESP32 compute
    ble_tx_power_mw: float = 28.0  # 28 mW Bluetooth Low Energy 5.2 transmission
    sensor_adc_power_mw: float = 8.5  # Analog front-end (AFE) ADC sampling power
    ble_bandwidth_kbps: float = 1000.0  # 1 Mbps BLE PHY throughput
    sampling_latency_ms: float = 2.5
    filter_latency_ms: float = 4.2
    edge_inference_latency_ms: float = 8.1
    server_inference_latency_ms: float = 6.4


@dataclass
class SystemConfig:
    dataset: DatasetConfig = field(default_factory=lambda: DATASET_CONFIGS["mit_bih"])
    model: ModelConfig = field(default_factory=ModelConfig)
    federated: FederatedMetaConfig = field(default_factory=FederatedMetaConfig)
    privacy: FRDPConfig = field(default_factory=FRDPConfig)
    dag: DAGBlockchainConfig = field(default_factory=DAGBlockchainConfig)
    stake_defense: StakeWeightedDeviationConfig = field(default_factory=StakeWeightedDeviationConfig)
    energy_latency: EdgeEnergyLatencyConfig = field(default_factory=EdgeEnergyLatencyConfig)
    random_seed: int = 42


def get_default_config(dataset_key: str = "mit_bih") -> SystemConfig:
    """Returns initialized configuration for the specified dataset."""
    cfg = SystemConfig()
    if dataset_key in DATASET_CONFIGS:
        cfg.dataset = DATASET_CONFIGS[dataset_key]
    return cfg
