"""
Split Federated-Meta Learning (Split-FedMeta) Engine
Implements Model-Agnostic Meta-Learning (MAML) coupled with Split Learning.
Enables rapid few-shot personalization for unseen patient ECG morphologies
while coordinating decentralized global meta-updates.
"""

import math
import copy
from typing import List, Dict, Tuple, Any

from src.models.edge_client_model import LightweightEdgeClientModel
from src.models.server_meta_model import ServerMetaClassifierModel


class SplitFederatedMetaLearner:
    """
    Split Federated-Meta Learning coordinator and patient adaptation manager.
    Coordinates inner-loop patient personalization and outer-loop meta-gradient aggregation.
    """

    def __init__(
        self,
        input_dim: int = 19,
        cut_dim: int = 64,
        num_classes: int = 5,
        inner_lr: float = 0.01,
        outer_lr: float = 0.005,
        inner_steps: int = 3,
        seed: int = 42
    ):
        self.input_dim = input_dim
        self.cut_dim = cut_dim
        self.num_classes = num_classes
        self.inner_lr = inner_lr
        self.outer_lr = outer_lr
        self.inner_steps = inner_steps

        # Global meta-initialization models
        self.global_client_model = LightweightEdgeClientModel(input_dim, cut_dim, seed=seed)
        self.global_server_model = ServerMetaClassifierModel(cut_dim, num_classes, seed=seed + 1)

    def adapt_patient_task(
        self,
        support_records: List[Dict[str, Any]],
        client_initial_weights: List[float] = None
    ) -> LightweightEdgeClientModel:
        """
        Inner Loop: Rapidly adapts client edge model to patient-specific cardiac features
        using few-shot support records (k-shot patient adaptation).
        """
        adapted_client = LightweightEdgeClientModel(self.input_dim, self.cut_dim)
        if client_initial_weights is not None:
            adapted_client.set_flat_weights(client_initial_weights)
        else:
            adapted_client.set_parameters(self.global_client_model.get_parameters())

        if not support_records:
            return adapted_client

        features = [r["feature_vector"] for r in support_records]
        labels = [r["class_index"] for r in support_records]

        # Inner loop gradient steps
        for _ in range(self.inner_steps):
            # Split forward
            z = adapted_client.forward(features)
            # Server forward (using current global server parameters for alignment)
            probs = self.global_server_model.forward(z)
            # Split backward
            grad_z, _ = self.global_server_model.backward(labels, lr=0.0)  # Do not mutate global server in inner loop
            # Client inner update
            adapted_client.backward(grad_z, lr=self.inner_lr)

        return adapted_client

    def evaluate_task(
        self,
        client_model: LightweightEdgeClientModel,
        records: List[Dict[str, Any]]
    ) -> Tuple[float, float, List[List[float]], List[int]]:
        """
        Evaluates task performance on given records.
        Returns: (loss, accuracy, predicted_probabilities, true_labels).
        """
        if not records:
            return 0.0, 0.0, [], []

        features = [r["feature_vector"] for r in records]
        labels = [r["class_index"] for r in records]

        z = client_model.forward(features)
        probs = self.global_server_model.forward(z)
        loss = self.global_server_model.compute_loss(probs, labels)

        preds = [max(range(len(p)), key=lambda c: p[c]) for p in probs]
        correct = sum(1 for pred, y in zip(preds, labels) if pred == y)
        accuracy = (correct / len(labels)) * 100.0

        return loss, accuracy, probs, labels

    def compute_client_meta_gradient(
        self,
        support_records: List[Dict[str, Any]],
        query_records: List[Dict[str, Any]]
    ) -> Tuple[List[float], float, float]:
        """
        Executes full MAML bi-level step for a single client task:
        1. Inner loop adaptation on support set.
        2. Meta-loss and meta-gradient computation on query set.
        Returns: (client_gradient_vector, pre_adapt_loss, post_adapt_acc).
        """
        # Pre-adaptation baseline evaluation
        pre_loss, _, _, _ = self.evaluate_task(self.global_client_model, query_records)

        # 1. Inner loop adaptation
        adapted_client = self.adapt_patient_task(support_records)

        # 2. Outer loop evaluation on query set
        post_loss, post_acc, _, _ = self.evaluate_task(adapted_client, query_records)

        # Compute meta-gradients w.r.t initial meta-weights
        # In First-Order MAML (FOMAML) / Reptile formulation:
        # meta_grad = initial_weights - adapted_weights
        init_weights = self.global_client_model.get_flat_weights()
        adapted_weights = adapted_client.get_flat_weights()

        client_meta_grad = [(w_init - w_adapt) for w_init, w_adapt in zip(init_weights, adapted_weights)]

        return client_meta_grad, pre_loss, post_acc

    def apply_meta_update(self, aggregated_client_grad: List[float], outer_lr: float = None):
        """
        Applies aggregated meta-update to global client model weights:
        theta_client <- theta_client - beta * aggregated_meta_grad
        """
        lr = outer_lr if outer_lr is not None else self.outer_lr
        weights = self.global_client_model.get_flat_weights()

        updated_weights = [round(w - lr * g, 6) for w, g in zip(weights, aggregated_client_grad)]
        self.global_client_model.set_flat_weights(updated_weights)
