"""
Server Coordinator Meta-Model (Upper Split Classification Architecture)
Executes on the federated coordinator / cloud-edge server.
Receives privacy-preserving smashed representations from edge devices,
computes diagnostic class logits, and calculates split backward gradients.
"""

import math
import random
from typing import List, Dict, Tuple, Any


class ServerMetaClassifierModel:
    """
    Coordinator neural classifier.
    Maps smashed representation z_k: [B, cut_dim] -> class logits: [B, num_classes].
    """

    def __init__(self, cut_dim: int = 64, num_classes: int = 5, hidden_dim: int = 64, seed: int = 42):
        self.cut_dim = cut_dim
        self.num_classes = num_classes
        self.hidden_dim = hidden_dim
        self.rng = random.Random(seed)

        # Layer 1: cut_dim -> hidden_dim
        self.W1 = self._init_matrix(self.hidden_dim, self.cut_dim)
        self.b1 = [0.0] * self.hidden_dim

        # Layer 2: hidden_dim -> num_classes
        self.W2 = self._init_matrix(self.num_classes, self.hidden_dim)
        self.b2 = [0.0] * self.num_classes

        # Backprop caches
        self.last_z: List[List[float]] = []
        self.last_h: List[List[float]] = []
        self.last_probs: List[List[float]] = []

    def _init_matrix(self, rows: int, cols: int) -> List[List[float]]:
        std = math.sqrt(2.0 / cols)
        return [[round(self.rng.gauss(0.0, std), 5) for _ in range(cols)] for _ in range(rows)]

    def _relu(self, x: float) -> float:
        return max(0.0, x)

    def _relu_grad(self, x: float) -> float:
        return 1.0 if x > 0.0 else 0.0

    def _softmax(self, logits: List[float]) -> List[float]:
        max_l = max(logits)
        exp_vals = [math.exp(max(-30.0, min(30.0, l - max_l))) for l in logits]
        sum_exp = sum(exp_vals) + 1e-9
        return [round(e / sum_exp, 6) for e in exp_vals]

    def forward(self, batch_z: List[List[float]]) -> List[List[float]]:
        """
        Forward propagation across upper server layers.
        Returns predicted probabilities: [B, num_classes].
        """
        self.last_z = batch_z
        self.last_h = []
        self.last_probs = []

        batch_probs = []
        for z in batch_z:
            # Layer 1
            h = []
            for j in range(self.hidden_dim):
                val = self.b1[j]
                for i in range(self.cut_dim):
                    val += self.W1[j][i] * z[i]
                h.append(self._relu(val))

            # Layer 2
            logits = []
            for c in range(self.num_classes):
                val = self.b2[c]
                for j in range(self.hidden_dim):
                    val += self.W2[c][j] * h[j]
                logits.append(val)

            probs = self._softmax(logits)
            self.last_h.append(h)
            self.last_probs.append(probs)
            batch_probs.append(probs)

        return batch_probs

    def compute_loss(self, probs: List[List[float]], labels: List[int]) -> float:
        """Computes categorical cross-entropy loss."""
        total_loss = 0.0
        for p, y in zip(probs, labels):
            eps = 1e-12
            prob_y = max(eps, min(1.0 - eps, p[y]))
            total_loss -= math.log(prob_y)
        return total_loss / max(1, len(labels))

    def backward(self, labels: List[int], lr: float = 0.01) -> Tuple[List[List[float]], Dict[str, Any]]:
        """
        Computes backward gradients w.r.t server weights and
        split gradients w.r.t input smashed activations grad_z to return to edge client.
        """
        batch_size = max(1, len(labels))

        dW2 = [[0.0] * self.hidden_dim for _ in range(self.num_classes)]
        db2 = [0.0] * self.num_classes
        dW1 = [[0.0] * self.cut_dim for _ in range(self.hidden_dim)]
        db1 = [0.0] * self.hidden_dim
        grad_z = [[0.0] * self.cut_dim for _ in range(batch_size)]

        for b in range(batch_size):
            p = self.last_probs[b]
            y = labels[b]
            h = self.last_h[b]
            z = self.last_z[b]

            # Cross-entropy with softmax gradient: grad_logits = p - 1_y
            grad_logits = [p[c] - (1.0 if c == y else 0.0) for c in range(self.num_classes)]

            # Gradients for Layer 2
            grad_h = [0.0] * self.hidden_dim
            for c in range(self.num_classes):
                db2[c] += grad_logits[c]
                for j in range(self.hidden_dim):
                    dW2[c][j] += grad_logits[c] * h[j]
                    grad_h[j] += grad_logits[c] * self.W2[c][j]

            # Gradients for Layer 1
            for j in range(self.hidden_dim):
                pre_h = 0.0
                for i in range(self.cut_dim):
                    pre_h += self.W1[j][i] * z[i]
                pre_h += self.b1[j]

                grad_pre_h = grad_h[j] * self._relu_grad(pre_h)
                db1[j] += grad_pre_h
                for i in range(self.cut_dim):
                    dW1[j][i] += grad_pre_h * z[i]
                    grad_z[b][i] += grad_pre_h * self.W1[j][i]

        # Parameter update
        for c in range(self.num_classes):
            self.b2[c] -= lr * (db2[c] / batch_size)
            for j in range(self.hidden_dim):
                self.W2[c][j] -= lr * (dW2[c][j] / batch_size)

        for j in range(self.hidden_dim):
            self.b1[j] -= lr * (db1[j] / batch_size)
            for i in range(self.cut_dim):
                self.W1[j][i] -= lr * (dW1[j][i] / batch_size)

        server_grads = {
            "dW1": [[g / batch_size for g in row] for row in dW1],
            "dW2": [[g / batch_size for g in row] for row in dW2],
        }

        return grad_z, server_grads

    def get_parameters(self) -> Dict[str, Any]:
        return {
            "W1": [row[:] for row in self.W1],
            "b1": self.b1[:],
            "W2": [row[:] for row in self.W2],
            "b2": self.b2[:],
        }

    def set_parameters(self, params: Dict[str, Any]):
        self.W1 = [row[:] for row in params["W1"]]
        self.b1 = params["b1"][:]
        self.W2 = [row[:] for row in params["W2"]]
        self.b2 = params["b2"][:]

    def get_flat_weights(self) -> List[float]:
        flat = []
        for row in self.W1:
            flat.extend(row)
        flat.extend(self.b1)
        for row in self.W2:
            flat.extend(row)
        flat.extend(self.b2)
        return flat

    def set_flat_weights(self, flat: List[float]):
        idx = 0
        for j in range(self.hidden_dim):
            for i in range(self.cut_dim):
                self.W1[j][i] = flat[idx]
                idx += 1
        for j in range(self.hidden_dim):
            self.b1[j] = flat[idx]
            idx += 1
        for c in range(self.num_classes):
            for j in range(self.hidden_dim):
                self.W2[c][j] = flat[idx]
                idx += 1
        for c in range(self.num_classes):
            self.b2[c] = flat[idx]
            idx += 1
