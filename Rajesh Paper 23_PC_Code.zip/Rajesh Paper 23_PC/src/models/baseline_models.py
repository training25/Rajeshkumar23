"""
Comparative Baseline Architectures Module
Implements four standard benchmarking paradigms for ECG healthcare monitoring:
1. Centralized Deep Learning (Cloud Upper-Bound)
2. Standard FedAvg (Federated Averaging without DP/Blockchain)
3. FedProx with Standard DP (Proximal Regularization + Conventional Gaussian DP)
4. Blockchain-FL (FL with Linear Blockchain Ledger)
"""

import math
import random
from typing import List, Dict, Tuple, Any

from src.models.edge_client_model import LightweightEdgeClientModel
from src.models.server_meta_model import ServerMetaClassifierModel


class CentralizedBaselineModel:
    """Centralized learning baseline: All raw data pooled at the central cloud server."""

    def __init__(self, input_dim: int = 19, num_classes: int = 5, seed: int = 42):
        self.client_extractor = LightweightEdgeClientModel(input_dim, cut_dim=64, seed=seed)
        self.server_classifier = ServerMetaClassifierModel(cut_dim=64, num_classes=num_classes, seed=seed + 1)

    def train_epoch(self, records: List[Dict[str, Any]], lr: float = 0.01) -> float:
        features = [r["feature_vector"] for r in records]
        labels = [r["class_index"] for r in records]

        z = self.client_extractor.forward(features)
        probs = self.server_classifier.forward(z)
        loss = self.server_classifier.compute_loss(probs, labels)

        grad_z, _ = self.server_classifier.backward(labels, lr=lr)
        self.client_extractor.backward(grad_z, lr=lr)
        return loss

    def evaluate(self, records: List[Dict[str, Any]]) -> Tuple[float, float, List[List[float]], List[int]]:
        features = [r["feature_vector"] for r in records]
        labels = [r["class_index"] for r in records]

        z = self.client_extractor.forward(features)
        probs = self.server_classifier.forward(z)
        loss = self.server_classifier.compute_loss(probs, labels)

        preds = [max(range(len(p)), key=lambda c: p[c]) for p in probs]
        correct = sum(1 for p, y in zip(preds, labels) if p == y)
        acc = (correct / len(labels)) * 100.0

        return loss, acc, probs, labels


class FedAvgBaselineModel:
    """Standard Federated Averaging baseline (McMahan et al.)."""

    def __init__(self, input_dim: int = 19, num_classes: int = 5, seed: int = 42):
        self.global_client = LightweightEdgeClientModel(input_dim, cut_dim=64, seed=seed)
        self.global_server = ServerMetaClassifierModel(cut_dim=64, num_classes=num_classes, seed=seed + 1)

    def client_train_step(self, local_records: List[Dict[str, Any]], lr: float = 0.01) -> List[float]:
        client = LightweightEdgeClientModel(self.global_client.input_dim, self.global_client.cut_dim)
        client.set_flat_weights(self.global_client.get_flat_weights())

        features = [r["feature_vector"] for r in local_records]
        labels = [r["class_index"] for r in local_records]

        z = client.forward(features)
        probs = self.global_server.forward(z)
        grad_z, _ = self.global_server.backward(labels, lr=0.0)
        client.backward(grad_z, lr=lr)

        return client.get_flat_weights()

    def aggregate(self, client_weights_list: List[List[float]]):
        num_clients = len(client_weights_list)
        if num_clients == 0:
            return

        weight_len = len(client_weights_list[0])
        avg_weights = [0.0] * weight_len
        for w in client_weights_list:
            for i in range(weight_len):
                avg_weights[i] += w[i]

        avg_weights = [round(x / num_clients, 6) for x in avg_weights]
        self.global_client.set_flat_weights(avg_weights)


class FedProxDPBaselineModel:
    """FedProx with Standard Gaussian Differential Privacy baseline."""

    def __init__(self, input_dim: int = 19, num_classes: int = 5, mu_prox: float = 0.01, noise_sigma: float = 0.15, seed: int = 42):
        self.global_client = LightweightEdgeClientModel(input_dim, cut_dim=64, seed=seed)
        self.global_server = ServerMetaClassifierModel(cut_dim=64, num_classes=num_classes, seed=seed + 1)
        self.mu_prox = mu_prox
        self.noise_sigma = noise_sigma
        self.rng = random.Random(seed)

    def client_train_step(self, local_records: List[Dict[str, Any]], lr: float = 0.01) -> List[float]:
        client = LightweightEdgeClientModel(self.global_client.input_dim, self.global_client.cut_dim)
        client.set_flat_weights(self.global_client.get_flat_weights())
        global_flat = self.global_client.get_flat_weights()

        features = [r["feature_vector"] for r in local_records]
        labels = [r["class_index"] for r in local_records]

        z = client.forward(features)
        probs = self.global_server.forward(z)
        grad_z, _ = self.global_server.backward(labels, lr=0.0)
        client.backward(grad_z, lr=lr)

        # Proximal regularization + Gaussian DP perturbation
        weights = client.get_flat_weights()
        perturbed_weights = []
        for w, w_g in zip(weights, global_flat):
            # Proximal pull
            w_prox = w - lr * self.mu_prox * (w - w_g)
            # Add Gaussian noise for conventional DP
            noise = self.rng.gauss(0.0, self.noise_sigma)
            perturbed_weights.append(round(w_prox + noise, 6))

        return perturbed_weights

    def aggregate(self, client_weights_list: List[List[float]]):
        num_clients = len(client_weights_list)
        if num_clients == 0:
            return

        weight_len = len(client_weights_list[0])
        avg_weights = [sum(w[i] for w in client_weights_list) / num_clients for i in range(weight_len)]
        self.global_client.set_flat_weights(avg_weights)


class BlockchainFLBaselineModel:
    """Federated Learning with standard linear PoS blockchain consensus."""

    def __init__(self, input_dim: int = 19, num_classes: int = 5, seed: int = 42):
        self.fedavg = FedAvgBaselineModel(input_dim, num_classes, seed=seed)
        self.block_chain_height = 0
        self.linear_tx_pool: List[Dict[str, Any]] = []

    def submit_block(self, client_weights: List[List[float]]) -> Dict[str, Any]:
        """Simulates linear block production with sequential confirmation overhead."""
        self.block_chain_height += 1
        block = {
            "block_index": self.block_chain_height,
            "num_txs": len(client_weights),
            "simulated_block_latency_sec": 4.5,  # Linear block delay
        }
        self.fedavg.aggregate(client_weights)
        return block
