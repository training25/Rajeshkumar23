"""
Lightweight Edge Client Model (Cut Layer Lower Architecture)
Executes on resource-constrained IoMT edge devices.
Extracts compressed, privacy-preserving latent representations (smashed activations)
from multi-modal physiological features without exposing raw medical biosignals.
"""

import math
import random
from typing import List, Dict, Tuple, Any


class LightweightEdgeClientModel:
    """
    Lightweight edge neural representation extractor.
    Implements a 2-layer depthwise-separable MLP/Conv abstraction with Swish activations.
    Computes smashed feature embeddings: z_k = f_client(x_k; theta_client).
    """

    def __init__(self, input_dim: int = 19, cut_dim: int = 64, seed: int = 42):
        self.input_dim = input_dim
        self.cut_dim = cut_dim
        self.hidden_dim = 48
        self.rng = random.Random(seed)

        # Initialize weights with He (Kaiming) normal initialization
        self.W1 = self._init_matrix(self.hidden_dim, self.input_dim)
        self.b1 = [0.0] * self.hidden_dim

        self.W2 = self._init_matrix(self.cut_dim, self.hidden_dim)
        self.b2 = [0.0] * self.cut_dim

        # Cache for backpropagation
        self.last_x: List[List[float]] = []
        self.last_h: List[List[float]] = []
        self.last_z: List[List[float]] = []

    def _init_matrix(self, rows: int, cols: int) -> List[List[float]]:
        std = math.sqrt(2.0 / cols)
        return [[round(self.rng.gauss(0.0, std), 5) for _ in range(cols)] for _ in range(rows)]

    def _swish(self, x: float) -> float:
        """Swish activation function: x * sigmoid(x)"""
        sig = 1.0 / (1.0 + math.exp(-max(-20.0, min(20.0, x))))
        return x * sig

    def _swish_grad(self, x: float) -> float:
        """Derivative of Swish activation: sig + x * sig * (1 - sig)"""
        sig = 1.0 / (1.0 + math.exp(-max(-20.0, min(20.0, x))))
        return sig + x * sig * (1.0 - sig)

    def forward(self, batch_x: List[List[float]]) -> List[List[float]]:
        """
        Forward propagation across client cut layer.
        Maps batch_x: [B, input_dim] -> smashed_z: [B, cut_dim].
        """
        self.last_x = batch_x
        self.last_h = []
        self.last_z = []

        batch_z = []
        for x in batch_x:
            # Layer 1
            h = []
            for j in range(self.hidden_dim):
                val = self.b1[j]
                for i in range(min(len(x), self.input_dim)):
                    val += self.W1[j][i] * x[i]
                h.append(self._swish(val))

            # Layer 2 (Cut layer projection)
            z = []
            for k in range(self.cut_dim):
                val = self.b2[k]
                for j in range(self.hidden_dim):
                    val += self.W2[k][j] * h[j]
                # Tanh bound on smashed features for gradient stability
                z.append(math.tanh(val))

            self.last_h.append(h)
            self.last_z.append(z)
            batch_z.append(z)

        return batch_z

    def backward(self, grad_z: List[List[float]], lr: float = 0.01) -> Dict[str, Any]:
        """
        Backpropagation from server split gradients: grad_z: [B, cut_dim].
        Computes gradients w.r.t client parameters and returns parameter updates.
        """
        batch_size = max(1, len(grad_z))

        dW2 = [[0.0] * self.hidden_dim for _ in range(self.cut_dim)]
        db2 = [0.0] * self.cut_dim
        dW1 = [[0.0] * self.input_dim for _ in range(self.hidden_dim)]
        db1 = [0.0] * self.hidden_dim

        for b in range(batch_size):
            h_b = self.last_h[b]
            z_b = self.last_z[b]
            gz_b = grad_z[b]
            x_b = self.last_x[b]

            grad_pre_z = [gz_b[k] * (1.0 - z_b[k] ** 2) for k in range(self.cut_dim)]

            grad_h = [0.0] * self.hidden_dim
            for k in range(self.cut_dim):
                db2[k] += grad_pre_z[k]
                for j in range(self.hidden_dim):
                    dW2[k][j] += grad_pre_z[k] * h_b[j]
                    grad_h[j] += grad_pre_z[k] * self.W2[k][j]

            # Layer 1 backprop
            for j in range(self.hidden_dim):
                pre_h = 0.0
                for i in range(min(len(x_b), self.input_dim)):
                    pre_h += self.W1[j][i] * x_b[i]
                pre_h += self.b1[j]

                grad_pre_h = grad_h[j] * self._swish_grad(pre_h)
                db1[j] += grad_pre_h
                for i in range(min(len(x_b), self.input_dim)):
                    dW1[j][i] += grad_pre_h * x_b[i]

        # Average and apply gradients
        for k in range(self.cut_dim):
            self.b2[k] -= lr * (db2[k] / batch_size)
            for j in range(self.hidden_dim):
                self.W2[k][j] -= lr * (dW2[k][j] / batch_size)

        for j in range(self.hidden_dim):
            self.b1[j] -= lr * (db1[j] / batch_size)
            for i in range(self.input_dim):
                self.W1[j][i] -= lr * (dW1[j][i] / batch_size)

        return {
            "dW1": [[g / batch_size for g in row] for row in dW1],
            "dW2": [[g / batch_size for g in row] for row in dW2],
        }

    def get_parameters(self) -> Dict[str, Any]:
        """Returns deep copy of client parameters."""
        return {
            "W1": [row[:] for row in self.W1],
            "b1": self.b1[:],
            "W2": [row[:] for row in self.W2],
            "b2": self.b2[:],
        }

    def set_parameters(self, params: Dict[str, Any]):
        """Sets client model parameters."""
        self.W1 = [row[:] for row in params["W1"]]
        self.b1 = params["b1"][:]
        self.W2 = [row[:] for row in params["W2"]]
        self.b2 = params["b2"][:]

    def get_flat_weights(self) -> List[float]:
        """Returns flattened 1D parameter vector."""
        flat = []
        for row in self.W1:
            flat.extend(row)
        flat.extend(self.b1)
        for row in self.W2:
            flat.extend(row)
        flat.extend(self.b2)
        return flat

    def set_flat_weights(self, flat: List[float]):
        """Restores model parameters from flat 1D vector."""
        idx = 0
        for j in range(self.hidden_dim):
            for i in range(self.input_dim):
                self.W1[j][i] = flat[idx]
                idx += 1
        for j in range(self.hidden_dim):
            self.b1[j] = flat[idx]
            idx += 1
        for k in range(self.cut_dim):
            for j in range(self.hidden_dim):
                self.W2[k][j] = flat[idx]
                idx += 1
        for k in range(self.cut_dim):
            self.b2[k] = flat[idx]
            idx += 1
