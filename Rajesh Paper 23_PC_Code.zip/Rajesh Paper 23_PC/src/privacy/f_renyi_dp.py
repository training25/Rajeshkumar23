"""
f-Divergence Renyi Differential Privacy (f-RDP) Module
Implements analytical Renyi Differential Privacy with Gaussian perturbation,
dynamic L2 gradient clipping, moments accountant composition,
hockey-stick f-divergence conversion to (epsilon, delta)-DP, and privacy leakage scoring.
"""

import math
import random
from typing import List, Dict, Tuple, Any


class FRenyiDifferentialPrivacy:
    """
    f-Divergence Renyi Differential Privacy mechanism.
    Provides mathematically tight privacy bounds and rigorous accounting across federated rounds.
    """

    def __init__(
        self,
        alpha: float = 4.0,
        target_delta: float = 1e-5,
        clipping_threshold: float = 1.0,
        noise_multiplier: float = 0.85,
        max_budget_epsilon: float = 4.0,
        seed: int = 42
    ):
        if alpha <= 1.0:
            raise ValueError(f"Renyi order alpha must be > 1.0, got {alpha}")

        self.alpha = float(alpha)
        self.target_delta = float(target_delta)
        self.clipping_threshold = float(clipping_threshold)  # S_g L2 sensitivity
        self.noise_multiplier = float(noise_multiplier)  # sigma / S_g
        self.sigma = self.noise_multiplier * self.clipping_threshold
        self.max_budget_epsilon = float(max_budget_epsilon)

        self.rng = random.Random(seed)
        self.cumulative_rounds = 0
        self.cumulative_rdp = 0.0

    def clip_gradient_l2(self, gradient: List[float]) -> Tuple[List[float], float]:
        """
        Enforces L2 sensitivity bound: g_clipped = g * min(1, S_g / ||g||_2).
        Returns: (clipped_gradient, original_l2_norm).
        """
        l2_norm = math.sqrt(sum(g ** 2 for g in gradient))
        if l2_norm <= 1e-12:
            return gradient[:], 0.0

        scaling = min(1.0, self.clipping_threshold / l2_norm)
        clipped = [round(g * scaling, 6) for g in gradient]
        return clipped, l2_norm

    def perturb_gradient(self, gradient: List[float]) -> Tuple[List[float], Dict[str, Any]]:
        """
        Clips gradient to L2 sensitivity threshold and adds calibrated Gaussian noise:
        g_private = clip(g) + N(0, sigma^2 I).
        Updates cumulative moments accountant.
        """
        clipped, original_norm = self.clip_gradient_l2(gradient)

        # Perturbation
        perturbed = []
        for g in clipped:
            noise = self.rng.gauss(0.0, self.sigma)
            perturbed.append(round(g + noise, 6))

        # Single-round Renyi divergence contribution: eps_R = alpha * S_g^2 / (2 * sigma^2)
        single_round_rdp = (self.alpha * (self.clipping_threshold ** 2)) / (2.0 * (self.sigma ** 2))
        self.cumulative_rdp += single_round_rdp
        self.cumulative_rounds += 1

        eps_converted = self.compute_converted_epsilon()
        leakage_score = self.compute_privacy_leakage_score()

        stats = {
            "round": self.cumulative_rounds,
            "original_l2_norm": round(original_norm, 4),
            "clipping_threshold": self.clipping_threshold,
            "single_round_rdp": round(single_round_rdp, 5),
            "cumulative_rdp": round(self.cumulative_rdp, 5),
            "converted_epsilon": round(eps_converted, 4),
            "target_delta": self.target_delta,
            "privacy_leakage_score": round(leakage_score, 4),
            "budget_exceeded": eps_converted > self.max_budget_epsilon,
        }

        return perturbed, stats

    def compute_converted_epsilon(self) -> float:
        """
        Converts cumulative RDP to standard (epsilon, delta)-DP via hockey-stick f-divergence bound:
        eps(delta) = eps_R(alpha) + ln(1 / delta) / (alpha - 1).
        """
        if self.alpha <= 1.0:
            return float("inf")
        conversion_term = math.log(1.0 / self.target_delta) / (self.alpha - 1.0)
        return self.cumulative_rdp + conversion_term

    def compute_optimal_alpha_epsilon(self) -> Tuple[float, float]:
        """
        Analytically optimizes Renyi order alpha* for minimal converted epsilon:
        alpha* = 1 + sqrt(2 * sigma^2 * ln(1 / delta) / (T * S_g^2)).
        """
        T = max(1, self.cumulative_rounds)
        variance_term = (self.clipping_threshold ** 2) * T / (2.0 * (self.sigma ** 2))
        optimal_alpha = 1.0 + math.sqrt(math.log(1.0 / self.target_delta) / max(1e-9, variance_term))
        optimal_alpha = max(1.1, min(128.0, optimal_alpha))

        min_epsilon = variance_term * optimal_alpha + math.log(1.0 / self.target_delta) / (optimal_alpha - 1.0)
        return optimal_alpha, min_epsilon

    def compute_privacy_leakage_score(self) -> float:
        """
        Calculates normalized information-theoretic privacy leakage score:
        L_priv = 1 - exp(-eps_converted / alpha) in [0, 1].
        """
        eps = self.compute_converted_epsilon()
        score = 1.0 - math.exp(-max(0.0, eps) / self.alpha)
        return max(0.0, min(1.0, score))

    def reset_accountant(self):
        """Resets privacy accountant state."""
        self.cumulative_rounds = 0
        self.cumulative_rdp = 0.0
