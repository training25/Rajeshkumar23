"""
Federated Meta-Learning Coordinator Module
Orchestrates Split Federated-Meta Learning rounds, anchors updates to the DAG ledger,
applies Smart Contract validation and Stake-Weighted Gradient Deviation defense,
and computes real-time system performance telemetry.
"""

import time
import math
import random
from typing import Dict, List, Tuple, Any

from src.config import SystemConfig
from src.data.ecg_datasets import ECGDatasetManager
from src.models.split_maml import SplitFederatedMetaLearner
from src.models.edge_client_model import LightweightEdgeClientModel
from src.blockchain.dag_ledger import LightweightDAGLedger
from src.blockchain.stake_gradient_deviation import StakeWeightedDeviationDefense
from src.blockchain.smart_contract import SmartContractValidator
from src.federated.edge_node import IoMTEdgeNode
from src.federated.reliability_evaluator import ClientReliabilityEvaluator


class FRDDABACoordinator:
    """
    Central orchestration coordinator for the f-RDDA-BA framework.
    Integrates Split-FedMeta, f-RDP, DAG Blockchain, and Byzantine Resilience.
    """

    def __init__(self, config: SystemConfig, dataset_manager: ECGDatasetManager = None):
        self.config = config
        self.rng = random.Random(config.random_seed)

        # 1. Dataset & Partitions
        self.dataset_manager = dataset_manager if dataset_manager is not None else ECGDatasetManager(
            dataset_name="mit_bih", seed=config.random_seed
        )
        self.client_partitions = self.dataset_manager.create_non_iid_federated_partitions(
            num_clients=config.federated.num_clients
        )
        _, self.val_records, self.test_records = self.dataset_manager.get_train_val_test_splits()

        # Input dimension from extracted features
        sample_feat_dim = len(self.val_records[0]["feature_vector"])

        # 2. Split Meta-Learner
        self.meta_learner = SplitFederatedMetaLearner(
            input_dim=sample_feat_dim,
            cut_dim=config.model.client_cut_dim,
            num_classes=config.dataset.num_classes,
            inner_lr=config.federated.inner_learning_rate,
            outer_lr=config.federated.outer_learning_rate,
            inner_steps=config.federated.inner_adaptation_steps,
            seed=config.random_seed
        )

        # 3. Blockchain & Defense Subsystems
        self.dag_ledger = LightweightDAGLedger(mcmc_lambda=config.dag.mcmc_lambda, seed=config.random_seed)
        self.stake_defense = StakeWeightedDeviationDefense(
            num_clients=config.federated.num_clients,
            gamma_multiplier=config.stake_defense.gamma_multiplier,
            cosine_threshold=config.stake_defense.cosine_threshold,
            slashing_penalty=config.dag.stake_slashing_penalty,
            reputation_reward=config.stake_defense.reputation_reward,
            min_stake=config.dag.minimum_valid_stake
        )
        self.smart_contract = SmartContractValidator(
            dag_ledger=self.dag_ledger,
            stake_defense=self.stake_defense,
            max_epsilon=config.privacy.max_privacy_budget_epsilon,
            max_skew_sec=config.dag.max_timestamp_skew_ms / 1000.0
        )
        self.reliability_evaluator = ClientReliabilityEvaluator(num_clients=config.federated.num_clients)

        # 4. Instantiate IoMT Edge Nodes
        self.edge_nodes: Dict[int, IoMTEdgeNode] = {}
        num_byzantine = int(config.federated.num_clients * config.federated.byzantine_client_ratio)
        byzantine_indices = set(self.rng.sample(range(config.federated.num_clients), num_byzantine))

        attack_types = config.federated.attack_types
        for cid in range(config.federated.num_clients):
            is_byz = cid in byzantine_indices
            attack = attack_types[cid % len(attack_types)] if is_byz else "none"
            self.edge_nodes[cid] = IoMTEdgeNode(
                client_id=cid,
                local_records=self.client_partitions[cid],
                input_dim=sample_feat_dim,
                cut_dim=config.model.client_cut_dim,
                is_byzantine=is_byz,
                attack_type=attack,
                energy_cfg=config.energy_latency,
                seed=config.random_seed
            )

        # Telemetry & History
        self.round_history: List[Dict[str, Any]] = []
        self.training_start_time = 0.0

    def _server_split_backward_fn(self, smashed_z: List[List[float]], labels: List[int]) -> List[List[float]]:
        """Server-side split function: predicts probabilities and returns split gradients grad_z."""
        probs = self.meta_learner.global_server_model.forward(smashed_z)
        grad_z, _ = self.meta_learner.global_server_model.backward(labels, lr=0.0)
        return grad_z

    def execute_training_round(self, round_num: int) -> Dict[str, Any]:
        """
        Executes one full global round of the f-RDDA-BA framework:
        1. Selects participating clients.
        2. Distributes global client model weights.
        3. Clients perform local MAML adaptation + f-RDP perturbation.
        4. Smart contract validates participant identity, freshness, and budget.
        5. Stake-weighted gradient deviation defends against Byzantine attacks.
        6. Aggregates approved meta-gradients and updates global meta-models.
        7. Evaluates global accuracy on validation set.
        """
        round_start = time.time()
        active_k = self.config.federated.active_clients_per_round
        active_client_ids = self.rng.sample(list(self.edge_nodes.keys()), active_k)

        global_client_weights = self.meta_learner.global_client_model.get_flat_weights()

        client_gradients: Dict[int, List[float]] = {}
        client_reports: Dict[int, Dict[str, Any]] = {}

        # Step A: Edge Client Local Processing
        for cid in active_client_ids:
            node = self.edge_nodes[cid]
            supp, query = self.dataset_manager.create_maml_task_batch(node.local_records)

            grad, report = node.local_maml_adaptation(
                support_records=supp,
                query_records=query,
                global_client_weights=global_client_weights,
                server_model_fn=self._server_split_backward_fn,
                inner_lr=self.config.federated.inner_learning_rate,
                inner_steps=self.config.federated.inner_adaptation_steps
            )
            client_gradients[cid] = grad
            client_reports[cid] = report

        # Step B: Smart Contract On-Chain Validation
        contract_approved_clients: Dict[int, List[float]] = {}
        for cid in active_client_ids:
            rep = client_reports[cid]
            is_valid, tx_receipt, status = self.smart_contract.validate_and_commit_update(
                client_id=cid,
                round_num=round_num,
                model_hash=rep["model_hash"],
                rdp_epsilon=rep["rdp_stats"]["converted_epsilon"],
                gradient_vector=rep["gradient"],
                signature=rep["signature"],
                timestamp=time.time()
            )
            if is_valid:
                contract_approved_clients[cid] = client_gradients[cid]

        # Step C: Stake-Weighted Gradient Deviation Byzantine Defense
        accepted_mask, final_meta_grad, defense_stats = self.stake_defense.evaluate_updates(
            contract_approved_clients
        )

        # Step D: Apply Global Meta-Update
        if final_meta_grad:
            self.meta_learner.apply_meta_update(final_meta_grad)
            # Update Server Classifier on aggregated query batches
            all_query_recs = []
            for cid in active_client_ids:
                if accepted_mask.get(cid, False):
                    _, q = self.dataset_manager.create_maml_task_batch(self.edge_nodes[cid].local_records)
                    all_query_recs.extend(q)

            if all_query_recs:
                q_feat = [r["feature_vector"] for r in all_query_recs]
                q_lbl = [r["class_index"] for r in all_query_recs]
                z_q = self.meta_learner.global_client_model.forward(q_feat)
                self.meta_learner.global_server_model.forward(z_q)
                self.meta_learner.global_server_model.backward(q_lbl, lr=self.config.federated.outer_learning_rate)

        # Step E: Validation Evaluation
        val_loss, val_acc, _, _ = self.meta_learner.evaluate_task(
            self.meta_learner.global_client_model, self.val_records
        )

        # Step F: Reliability & Resource Aggregation
        round_duration_sec = time.time() - round_start
        total_round_bytes = sum(client_reports[cid]["payload_bytes"] for cid in active_client_ids)
        avg_edge_energy = sum(client_reports[cid]["round_energy_joules"] for cid in active_client_ids) / len(active_client_ids)

        for cid in active_client_ids:
            was_acc = accepted_mask.get(cid, False)
            self.reliability_evaluator.record_round_outcome(
                client_id=cid,
                was_approved=was_acc,
                latency_ms=client_reports[cid]["latency_ms"],
                accuracy=val_acc
            )

        # Extract representative privacy metrics
        sample_rdp = client_reports[active_client_ids[0]]["rdp_stats"]

        round_summary = {
            "round": round_num,
            "val_loss": round(val_loss, 4),
            "val_acc": round(val_acc, 2),
            "active_clients": active_client_ids,
            "approved_clients_count": defense_stats.get("num_approved", 0),
            "rejected_byzantine_count": defense_stats.get("num_rejected", 0),
            "round_duration_sec": round(round_duration_sec, 3),
            "round_communication_kb": round(total_round_bytes / 1024.0, 2),
            "avg_edge_energy_joules": round(avg_edge_energy, 4),
            "converted_epsilon": sample_rdp["converted_epsilon"],
            "privacy_leakage_score": sample_rdp["privacy_leakage_score"],
        }

        self.round_history.append(round_summary)
        return round_summary

    def run_training_campaign(self, num_rounds: int = None) -> List[Dict[str, Any]]:
        """Executes full multi-round federated training campaign."""
        rounds = num_rounds if num_rounds is not None else self.config.federated.num_global_rounds
        self.training_start_time = time.time()

        for r in range(1, rounds + 1):
            self.execute_training_round(r)

        return self.round_history
