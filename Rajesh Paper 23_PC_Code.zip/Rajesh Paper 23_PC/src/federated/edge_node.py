"""
IoMT Edge Node Simulation Module
Simulates wearable biosignal sensors / bedside monitors with resource constraints,
energy consumption modeling, local cut-layer execution, f-RDP perturbation, and Byzantine attack simulation.
"""

import time
import hashlib
import math
import random
from typing import List, Dict, Tuple, Any

from src.models.edge_client_model import LightweightEdgeClientModel
from src.privacy.f_renyi_dp import FRenyiDifferentialPrivacy
from src.config import EdgeEnergyLatencyConfig


class IoMTEdgeNode:
    """
    Represents an IoMT edge wearable or bedside health monitor.
    Processes local physiological biosignals, computes smashed features,
    applies f-RDP perturbation, and tracks hardware energy dissipation.
    """

    def __init__(
        self,
        client_id: int,
        local_records: List[Dict[str, Any]],
        input_dim: int = 19,
        cut_dim: int = 64,
        is_byzantine: bool = False,
        attack_type: str = "none",
        energy_cfg: EdgeEnergyLatencyConfig = None,
        seed: int = 42
    ):
        self.client_id = client_id
        self.local_records = local_records
        self.input_dim = input_dim
        self.cut_dim = cut_dim
        self.is_byzantine = is_byzantine
        self.attack_type = attack_type
        self.energy_cfg = energy_cfg if energy_cfg is not None else EdgeEnergyLatencyConfig()

        self.rng = random.Random(seed + client_id)

        # Local Cut-Layer Model
        self.local_model = LightweightEdgeClientModel(input_dim, cut_dim, seed=seed + client_id)

        # Local f-RDP Privacy Engine
        self.privacy_engine = FRenyiDifferentialPrivacy(seed=seed + client_id)

        # Cumulative Resource Metrics
        self.cumulative_energy_joules = 0.0
        self.cumulative_comm_bytes = 0

    def generate_signature(self, model_hash: str) -> str:
        """Generates cryptographic identity signature."""
        return hashlib.sha256(f"CLIENT_{self.client_id}_{model_hash}".encode("utf-8")).hexdigest()[:16]

    def _hash_vector(self, vec: List[float]) -> str:
        s = ",".join(f"{v:.4f}" for v in vec[:50])
        return hashlib.sha256(s.encode("utf-8")).hexdigest()

    def local_maml_adaptation(
        self,
        support_records: List[Dict[str, Any]],
        query_records: List[Dict[str, Any]],
        global_client_weights: List[float],
        server_model_fn: Any,
        inner_lr: float = 0.01,
        inner_steps: int = 3
    ) -> Tuple[List[float], Dict[str, Any]]:
        """
        Executes local inner-loop personalization and calculates perturbed meta-gradients:
        1. Adapts local cut model on patient support set.
        2. Evaluates query set.
        3. Applies f-RDP Gaussian perturbation.
        4. Simulates Byzantine behavior if node is compromised.
        5. Tracks energy consumption and communication bytes.
        """
        start_time = time.time()
        self.local_model.set_flat_weights(global_client_weights)

        # 1. Inner adaptation
        supp_features = [r["feature_vector"] for r in support_records]
        supp_labels = [r["class_index"] for r in support_records]

        for _ in range(inner_steps):
            z = self.local_model.forward(supp_features)
            grad_z = server_model_fn(z, supp_labels)
            self.local_model.backward(grad_z, lr=inner_lr)

        # 2. Outer gradient computation on query set
        adapted_weights = self.local_model.get_flat_weights()
        meta_grad = [w_init - w_adapt for w_init, w_adapt in zip(global_client_weights, adapted_weights)]

        # 3. Byzantine Attack Injection (if compromised)
        if self.is_byzantine:
            if self.attack_type == "sign_inversion":
                meta_grad = [-3.0 * g for g in meta_grad]
            elif self.attack_type == "gaussian_noise":
                meta_grad = [self.rng.gauss(0.0, 2.5) for _ in meta_grad]
            elif self.attack_type == "targeted_flip":
                meta_grad = [g + self.rng.gauss(1.5, 0.4) for g in meta_grad]

        # 4. f-RDP Perturbation
        perturbed_grad, rdp_stats = self.privacy_engine.perturb_gradient(meta_grad)

        # 5. Energy and Resource Accounting
        # Time components
        t_compute = (self.energy_cfg.filter_latency_ms + self.energy_cfg.edge_inference_latency_ms) / 1000.0
        # Payload: Smashed activations + meta gradient + metadata
        payload_bytes = len(perturbed_grad) * 4 + self.cut_dim * len(query_records) * 4 + 256
        t_tx = (payload_bytes * 8) / (self.energy_cfg.ble_bandwidth_kbps * 1000.0)

        # Electrical energy: E = P_cpu * t_cpu + P_tx * t_tx (in Joules)
        round_energy_joules = (self.energy_cfg.mcu_compute_power_mw / 1000.0) * t_compute + \
                              (self.energy_cfg.ble_tx_power_mw / 1000.0) * t_tx

        self.cumulative_energy_joules += round_energy_joules
        self.cumulative_comm_bytes += payload_bytes

        # Cryptographic model hash and signature
        model_hash = self._hash_vector(perturbed_grad)
        signature = self.generate_signature(model_hash)

        report = {
            "client_id": self.client_id,
            "is_byzantine": self.is_byzantine,
            "gradient": perturbed_grad,
            "model_hash": model_hash,
            "signature": signature,
            "rdp_stats": rdp_stats,
            "round_energy_joules": round(round_energy_joules, 6),
            "payload_bytes": payload_bytes,
            "latency_ms": round((time.time() - start_time) * 1000.0 + self.energy_cfg.edge_inference_latency_ms, 2),
        }

        return perturbed_grad, report
