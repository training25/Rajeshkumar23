"""
Client Reliability & Trust Evaluation Module
Tracks historical client consistency, validation accuracy, and participation reliability.
"""

from typing import Dict, List, Any


class ClientReliabilityEvaluator:
    """
    Maintains historical trust and reliability scores for edge clients.
    Assists the coordinator in stake weighting and adaptive client selection.
    """

    def __init__(self, num_clients: int = 10, window_size: int = 5):
        self.num_clients = num_clients
        self.window_size = window_size
        self.history: Dict[int, List[Dict[str, Any]]] = {i: [] for i in range(num_clients)}

    def record_round_outcome(self, client_id: int, was_approved: bool, latency_ms: float, accuracy: float):
        """Records client contribution outcome in current round."""
        entry = {
            "approved": was_approved,
            "latency_ms": latency_ms,
            "accuracy": accuracy,
        }
        self.history[client_id].append(entry)
        if len(self.history[client_id]) > self.window_size:
            self.history[client_id].pop(0)

    def get_reliability_score(self, client_id: int) -> float:
        """
        Computes rolling reliability score in [0.1, 1.0].
        Score = 0.7 * approval_rate + 0.3 * normalized_accuracy.
        """
        records = self.history.get(client_id, [])
        if not records:
            return 1.0

        approvals = sum(1 for r in records if r["approved"])
        approval_rate = approvals / len(records)

        avg_acc = sum(r["accuracy"] for r in records) / (len(records) * 100.0)
        score = 0.70 * approval_rate + 0.30 * avg_acc
        return round(max(0.10, min(1.0, score)), 4)
