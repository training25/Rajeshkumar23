"""
f-RDDA-BA: Privacy-Preserving Federated Meta Learning for ECG Healthcare Monitoring
Using Lightweight Blockchain and Edge Intelligence Privacy
"""

__version__ = "1.0.0"
__author__ = "Advanced Healthcare AI & Decentralized Systems Group"
