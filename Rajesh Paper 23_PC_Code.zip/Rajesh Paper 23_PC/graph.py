import matplotlib.pyplot as plt
import numpy as np

# Set global font to Times New Roman, size 20, bold
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['font.size'] = 20
plt.rcParams['font.weight'] = 'bold'
plt.rcParams['axes.labelweight'] = 'bold'
plt.rcParams['axes.titleweight'] = 'bold'

# Methods
methods = ['Centralize', 'FedAvg', 'FedProx+H', 'Blockchain', 'f-RDDA-BA\n(Proposed)']
x = np.arange(len(methods))
width = 0.6
colors = ['#4C72B0', '#55A868', '#C44E52', '#8172B2', '#CCB974']

# Data
data = {
    'Classification Accuracy (%)': [97.4, 91.2, 86.8, 90.4, 98.8],
    'Precision (%)':               [96.8, 89.5, 85.4, 89.6, 99.2],
    'Recall (%)':                  [97.0, 90.1, 86.2, 90.0, 98.5],
    'Specificity (%)':             [98.9, 95.8, 92.4, 95.5, 99.8],
    'F1-Score (%)':                [96.9, 89.8, 85.8, 89.8, 98.3],
    'AUC-ROC':                     [0.972, 0.952, 0.928, 0.951, 0.9892],
    'End-to-End Latency (ms)':     [78.5, 52, 48, 115, 33.2],
    'Convergence Rounds':          [14, 22, 28, 26, 16],
    'Convergence Time (s)':        [84, 132, 168, 245, 78.4],
    'Communication Cost (MB)':     [640, 128, 135, 285, 142.5],
    'Blockchain Overhead':         [25, 150, 180, 185, 342],
    'Energy Consumption (J)':      [2.15, 1.12, 1.25, 1.75, 0.78],
    'Energy Efficiency':           [0.5972, 0.3111, 0.3472, 0.4861, 0.2167],
    'Privacy Leakage':             [1.0, 0.65, 0.28, 0.58, 0.0864],
    'Model Size (MB)':             [15.6, 8.12, 6.3, 6.95, 3.48],
    'Health Score (%)':            [98.2, 98.8, 99.0, 99.4, 99.95],
}

# Create a separate bar graph for each metric
for metric, values in data.items():
    fig, ax = plt.subplots(figsize=(10, 6))
    
    bars = ax.bar(x, values, width, color=colors, edgecolor='black', linewidth=1.2)
    
    ax.set_ylabel(metric, fontsize=20, fontweight='bold', fontfamily='Times New Roman')
    ax.set_xticks(x)
    ax.set_xticklabels(methods, fontsize=18, fontweight='bold', fontfamily='Times New Roman')
    ax.tick_params(axis='y', labelsize=18)
    
    # Make y-tick labels bold Times New Roman
    for label in ax.get_yticklabels():
        label.set_fontname('Times New Roman')
        label.set_fontweight('bold')
    
    # Closed border (all four sides visible)
    for spine in ax.spines.values():
        spine.set_visible(True)
        spine.set_linewidth(1.5)
    
    ax.grid(axis='y', linestyle='--', alpha=0.4)
    
    plt.tight_layout()
    # Optional: save each figure
    # safe_name = metric.replace(' ', '_').replace('(', '').replace(')', '').replace('%', 'pct')
    # plt.savefig(f'{safe_name}.png', dpi=300, bbox_inches='tight')
    plt.show()