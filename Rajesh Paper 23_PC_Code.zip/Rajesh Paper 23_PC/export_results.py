"""
Results Export Utility
Exports all 15 benchmark metrics across datasets and comparative baselines
into CSV files, JSON summaries, and publication-ready LaTeX tables.
"""

import os
import json
import csv
from typing import Dict, Any

from src.config import RESULTS_DIR


def export_to_latex_table(results_dict: Dict[str, Any], filepath: str):
    """Generates LaTeX table code for research paper publication."""
    latex_code = [
        r"\begin{table*}[t]",
        r"\centering",
        r"\caption{Comprehensive Evaluation of Proposed f-RDDA-BA vs. Baseline Architectures across All 15 Metrics}",
        r"\label{tab:comprehensive_metrics}",
        r"\resizebox{\textwidth}{!}{",
        r"\begin{tabular}{l|c|cccc|c}",
        r"\hline",
        r"\textbf{Metric Category} & \textbf{Evaluation Metric} & \textbf{Centralized} & \textbf{FedAvg} & \textbf{FedProx+DP} & \textbf{Blockchain-FL} & \textbf{f-RDDA-BA (Proposed)} \\ \hline",
    ]

    metrics = [
        ("Diagnostic Fidelity", "Accuracy (\\%)", "1_classification_accuracy"),
        ("Diagnostic Fidelity", "Precision (\\%)", "2_precision"),
        ("Diagnostic Fidelity", "Recall / Sensitivity (\\%)", "3_recall_sensitivity"),
        ("Diagnostic Fidelity", "Specificity (\\%)", "4_specificity"),
        ("Diagnostic Fidelity", "F1-Score (\\%)", "5_f1_score"),
        ("Diagnostic Fidelity", "AUC-ROC", "6_auc_roc"),
        ("System Efficiency", "End-to-End Latency (ms)", "7_end_to_end_latency_ms"),
        ("System Efficiency", "Convergence Rounds", "8_convergence_rounds"),
        ("Communication", "Comm. Overhead (KB/round)", "9_communication_overhead_kb_per_round"),
        ("Blockchain Ledger", "Throughput (TPS)", "10_blockchain_throughput_tps"),
        ("Blockchain Ledger", "Confirmation Latency (ms)", "11_blockchain_confirmation_latency_ms"),
        ("IoMT Resource", "Energy Consumption (J)", "12_energy_consumption_joules"),
        ("Privacy & Security", "Privacy Leakage Score $\\mathcal{L}_{\\text{priv}}$", "13_privacy_leakage_score"),
        ("Communication", "Total Model Comm. Cost (MB)", "14_model_communication_cost_mb"),
        ("Resilience", "Healthcare Data Availability (\\%)", "15_healthcare_data_availability_pct"),
    ]

    current_cat = ""
    for cat, label, key in metrics:
        cat_str = f"\\multirow{{6}}{{*}}{{{cat}}}" if cat != current_cat else ""
        current_cat = cat

        v_c = results_dict.get("Centralized", {}).get(key, "-")
        v_fa = results_dict.get("FedAvg", {}).get(key, "-")
        v_fp = results_dict.get("FedProx+DP", {}).get(key, "-")
        v_bc = results_dict.get("Blockchain-FL", {}).get(key, "-")
        v_prop = results_dict.get("f-RDDA-BA (Proposed)", {}).get(key, "-")

        latex_code.append(f"{cat} & {label} & {v_c} & {v_fa} & {v_fp} & {v_bc} & \\textbf{{{v_prop}}} \\\\")

    latex_code.extend([
        r"\hline",
        r"\end{tabular}",
        r"}",
        r"\end{table*}",
    ])

    with open(filepath, "w", encoding="utf-8") as f:
        f.write("\n".join(latex_code))


def export_to_csv(results_dict: Dict[str, Any], filepath: str):
    """Exports comparative metrics to CSV format."""
    methods = list(results_dict.keys())
    if not methods:
        return

    sample_metrics = results_dict[methods[0]]
    metric_keys = list(sample_metrics.keys())

    with open(filepath, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["Metric"] + methods)

        for key in metric_keys:
            row = [key] + [results_dict[m].get(key, "") for m in methods]
            writer.writerow(row)


def main():
    bench_file = os.path.join(RESULTS_DIR, "comparative_benchmark_results.json")
    if not os.path.exists(bench_file):
        print(f"[!] Warning: {bench_file} not found. Run run_comparative_benchmark.py first.")
        return

    with open(bench_file, "r", encoding="utf-8") as f:
        data = json.load(f)

    csv_out = os.path.join(RESULTS_DIR, "comparative_metrics_table.csv")
    tex_out = os.path.join(RESULTS_DIR, "latex_table_results.tex")

    export_to_csv(data, csv_out)
    export_to_latex_table(data, tex_out)

    print(f"[+] CSV table exported to: {csv_out}")
    print(f"[+] LaTeX table exported to: {tex_out}")


if __name__ == "__main__":
    main()
