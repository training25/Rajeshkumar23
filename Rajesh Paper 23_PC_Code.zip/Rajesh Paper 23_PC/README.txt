# f-RDDA-BA Project Workspace
Target Directory: C:\work\Rajesh kumar3
Initialized: 2026-10-27
