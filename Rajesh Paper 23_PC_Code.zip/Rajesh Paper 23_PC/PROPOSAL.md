# Research Project Proposal

# f-RDDA-BA: Privacy-Preserving Federated Meta Learning for ECG Healthcare Monitoring Using Lightweight Blockchain and Edge Intelligence Privacy

**Principal Investigator / Research Team**: Advanced Healthcare AI & Decentralized Systems Group  
**Target Repository & Execution Directory**: `C:\work\Rajesh kumar3`  
**Date**: October 2026  
**Document Type**: Comprehensive Research Proposal & Technical Specification  

---

## Executive Summary

The Internet of Medical Things (IoMT) and wearable sensing technologies have revolutionized personalized patient care by enabling continuous, real-time physiological monitoring. Electrocardiogram (ECG) data, accompanied by vital signs such as heart rate (HR), blood pressure (BP), oxygen saturation ($\text{SpO}_2$), and body temperature, are vital for timely detection of cardiovascular diseases (CVDs)—the leading cause of global mortality. However, conventional centralized health-monitoring architectures introduce critical privacy vulnerabilities, single points of failure (SPoFs), high communication latency, and severe compliance risks under global health privacy regulations (e.g., HIPAA, GDPR).

While Federated Learning (FL) enables distributed model training without transferring raw patient biosignals, standard FL suffers from:
1. Significant vulnerability to gradient leakage and inference attacks.
2. High client statistical heterogeneity (non-IID patient data distributions).
3. The computational and communication burden of heavy cryptographic primitives.
4. Susceptibility to model poisoning, free-riding, and Byzantine updates from compromised edge nodes.
5. Inability to provide tamper-proof provenance, auditability, and decentralized consensus without prohibitive blockchain overhead.

To resolve these pressing bottlenecks, this proposal establishes **f-RDDA-BA**: a novel framework integrating **Split Federated-Meta Learning (Split-FedMeta)**, **$f$-Divergence Rényi Differential Privacy ($f$-RDP)**, and a **Lightweight Decentralized Directed Acyclic Graph (DAG) Blockchain Aggregation Protocol** with **Stake-Weighted Gradient Deviation verification**. By coupling edge intelligence with decentralized DAG ledger validation, $f$-RDDA-BA guarantees strict privacy bounds, rapid personalization for unseen patient biometrics, Byzantine-robust consensus, and low-latency continuous ECG healthcare monitoring. The framework is evaluated across three gold-standard ECG benchmark datasets from the open-source ECG repository catalogue (`MIT-BIH Arrhythmia`, `PTB-XL`, and `Chapman-Shaoxing`) across 15 rigorous clinical, computational, blockchain, and privacy performance metrics.

---

## 1. Introduction

Continuous physiological healthcare monitoring using Internet of Medical Things (IoMT) devices, wearable ECG patches, smartwatches, and bedside telemonitoring nodes enables proactive clinical intervention, preventing catastrophic cardiac events such as ventricular fibrillation, myocardial infarction, and acute heart failure. These biosensors generate continuous, multi-parametric temporal data streams comprising ECG waveforms, photoplethysmography (PPG), arterial blood pressure, and core temperature.

Despite its clinical transformative potential, large-scale deployment faces multi-dimensional hurdles:
* **Privacy and Regulatory Constraints**: Medical data contains deeply sensitive, identifiable biological signatures. Centralized collection of physiological telemetry violates patient sovereignty and creates massive honey-pot targets for ransomware and illicit surveillance.
* **Resource Constraints at the Edge**: Wearable medical microcontrollers and edge gateways possess strictly constrained battery life, limited SRAM/Flash memory, and modest compute capacity, preventing execution of heavyweight homomorphic encryption or large deep neural networks.
* **Communication Latency & Bandwidth Limitations**: Continuous streaming of multi-lead raw biosignals to centralized cloud servers saturates wireless bandwidth (e.g., BLE, 5G, Wi-Fi) and causes latency unacceptable for emergency cardiac arrest alerting.
* **Device and Patient Heterogeneity**: Physiological characteristics vary widely across demographic cohorts, age groups, and underlying comorbidities (non-IID distributions). A single global deep learning model often performs poorly on outlier patients without local adaptation.
* **Trust, Integrity, and Byzantine Attacks**: Distributed edge devices deployed in uncontrolled physical environments are susceptible to physical tampering, sensor fault drift, and deliberate adversarial model poisoning (e.g., label flipping or backdooring cardiac alarms).

Federated Learning (FL) decentralizes model optimization by transmitting model parameters or gradients rather than raw patient data. However, transmitting plain gradients is still vulnerable to deep gradient inversion attacks (e.g., DLG/iDLG). Adding standard Differential Privacy (DP) via traditional $(\epsilon, \delta)$ mechanisms often degrades diagnostic utility significantly. Furthermore, traditional linear Proof-of-Work (PoW) or Proof-of-Stake (PoS) blockchains introduce prohibitive transaction confirmation latency (tens of seconds to minutes), high energy waste, and severe transaction throughput bottlenecks (5–15 TPS).

To overcome these intersecting challenges, this project formulates the **f-RDDA-BA** architecture. The proposed framework establishes a synergy between:
1. **Edge Intelligence**: Local lightweight pre-processing, noise filtering, and temporal feature extraction.
2. **Split Federated-Meta Learning**: Splitting model execution between edge nodes (feature representation) and coordinator nodes, combined with Model-Agnostic Meta-Learning (MAML) for rapid few-shot patient personalization.
3. **$f$-Divergence Rényi Differential Privacy ($f$-RDP)**: Tighter composition bounds for privacy leakage accounting under Gaussian perturbation, optimizing the privacy-utility tradeoff.
4. **Decentralized DAG Blockchain Ledger**: Asynchronous, highly scalable, lightweight ledger operating without energy-intensive mining, utilizing a tip-selection algorithm and smart-contract verification to record tamper-proof transaction metadata, client reputations, and model hashes.
5. **Stake-Weighted Gradient Deviation Protocol**: An adaptive Byzantine defense mechanism that weights update consistency against cryptographic client stakes, rejecting malicious or corrupted updates before aggregation.

---

## 2. Comprehensive Literature Review

Recent academic investigations have explored the convergence of Federated Learning, Blockchain technology, and Edge Computing in IoMT ecosystems. A systematic examination of foundational works reveals critical milestones and unresolved operational barriers:

1. **Reddy GR et al. [6]** proposed a blockchain-based federated learning framework for secure IoMT data processing. They introduced a cluster-based aggregation scheme on edge nodes with mutual key agreement for parameter privacy. *Limitation*: The reliance on traditional blockchain architectures introduced noticeable latency overhead, and the framework lacked meta-learning capabilities for rapid personalization across highly non-IID patient cohorts.
2. **Abubaker Z et al. [7]** developed the Smart Privacy-Preserving Patient Monitoring (SP3M) framework, combining edge-cloud federated learning, blockchain-based trust management, and IPFS decentralized storage across a four-layer architecture (sensing, blockchain, edge intelligence, cloud). *Limitation*: While IPFS reduced on-chain storage costs, IPFS retrieval latency impaired real-time cardiac emergency response, and gradient inversion risks remained unmitigated by formal differential privacy bounds.
3. **Srivastava S et al. [8]** designed an incremental learning framework fusing federated learning, blockchain, and transformer models for cognitive health monitoring on the MODMA dataset, employing Rényi Differential Privacy (RDP) accounting. *Limitation*: The transformer architecture imposed excessive memory and computational burdens on resource-limited edge nodes, and the consensus mechanism was linear and non-scalable for high-frequency IoMT networks.
4. **Kale M et al. [9]** developed *Fed Shield*, a blockchain-enabled FL framework for intrusion detection in consumer IoT healthcare. They trained a hybrid CNN-KNN ensemble on virtual machines, using Proof-of-Stake (PoS) and IPFS for on-chain storage reduction. *Limitation*: Offloading to virtual machines deviates from true on-device edge computing, and PoS consensus still exhibited block creation delays incompatible with sub-second biosignal anomaly detection.
5. **Melhem A et al. [10]** proposed *C2SecFL*, combining model-aware clustering with Inner-Product Functional Encryption (IPFE) and a lightweight permissioned blockchain for secure cross-cluster aggregation. *Limitation*: IPFE introduces non-trivial cryptographic key distribution dependencies and high computational overhead for multi-lead ECG feature vectors.
6. **Surasak T et al. [11]** constructed a lightweight blockchain-verified federated learning framework for patient monitoring, anchoring model hashes and client metadata to an immutable ledger while keeping synthetic records locally. *Limitation*: The framework lacked adaptive Byzantine fault tolerance against subtle gradient manipulation attacks and did not address personalized few-shot adaptation for rare cardiac arrhythmias.
7. **Yang J et al. [12]** introduced *MediChain-FSL*, combining blockchain, federated semi-supervised learning, consistency regularization, and differential privacy for breast cancer assessment. *Limitation*: The dual semi-supervised pipeline requires extensive local unlabeled data and dual-network consistency checks, which exhaust the battery and processing budgets of wearable IoMT nodes.
8. **Babar M et al. [13]** proposed an attack detection scheme merging split federated learning, blockchain smart contracts, and edge intelligence using lightweight CNN and BiLSTM networks. *Limitation*: While split learning relieved edge computation, the server-side model aggregation lacked meta-learning generalization and privacy composition guarantees against reconstruction attacks on intermediate smashed activations.
9. **Ahmad S et al. [14]** conducted a comprehensive survey on fog/edge machine learning integration for remote healthcare, emphasizing the critical tradeoffs among latency, energy, privacy, and clinical interoperability. *Insight*: They concluded that pure cloud or pure edge architectures are insufficient; hybrid split architectures with formal mathematical privacy bounds and decentralized verification represent the vital path forward.
10. **Ali S et al. [15]** explored the architectural union of blockchain and federated learning in decentralized electronic health systems. *Insight*: They highlighted that conventional chain-structured blockchains (e.g., Ethereum/Hyperledger Fabric) become severe throughput bottlenecks under frequent FL communication rounds, advocating for asynchronous DAG-based ledgers.

### Comparative Synthesis of State-of-the-Art vs. Proposed f-RDDA-BA

| Feature / Dimension | Reddy et al. [6] | Abubaker et al. [7] | Srivastava et al. [8] | Babar et al. [13] | Proposed **f-RDDA-BA** |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Privacy Mechanism** | Key Agreement | None (Storage Only)| RDP on Transformer | None | **$f$-Divergence RDP ($f$-RDP)** |
| **Learning Paradigm** | Standard FedAvg | Clustered FL | Incremental FL | Split FL | **Split Federated-Meta Learning (MAML)** |
| **Ledger Architecture** | Permissioned Chain | Consortium Chain | Linear Blockchain | Smart Contracts (Chain)| **Decentralized DAG (Tangle-style)** |
| **Consensus Latency** | High (5–12 s) | High (8–15 s) | Moderate (4–10 s) | Moderate (3–8 s) | **Ultra-Low Sub-Second (< 250 ms)** |
| **Byzantine Defense** | Cluster verification| Trust score | Anomaly threshold | Basic Trust score | **Stake-Weighted Gradient Deviation** |
| **Edge Footprint** | Moderate | High (IPFS node) | Very High (Transformer)| Low (Split CNN) | **Ultra-Lightweight (Depthwise 1D-CNN)** |
| **Personalization** | No | No | Partial (Incremental)| No | **Yes (Few-Shot Fast Adaptation)** |
| **Multi-modal Biosignals**| ECG Only | Multimodal | Cognitive/EEG | Network/IoT | **ECG + HR + BP + $\text{SpO}_2$ + Temp** |

---

## 3. Research Gaps

Despite progressive milestones in decentralized health monitoring, current paradigms exhibit critical scientific and practical shortcomings:
1. **Inefficient Privacy Accounting and the Utility Destruction Problem**: Standard $(\epsilon, \delta)$-Differential Privacy introduces excessive stochastic Gaussian noise that obliterates fine morphological ECG anomalies (such as subtle ST-segment elevations or P-wave inversions). Current systems lack tight, analytical $f$-divergence Rényi composition bounds that preserve high diagnostic accuracy while ensuring mathematically provable privacy.
2. **Absence of Few-Shot Personalization in Heterogeneous Biosignals**: Inter-patient physiological variability causes severe statistical heterogeneity (non-IID). Existing healthcare FL schemes aggregate updates into an average global model that fails to detect rare arrhythmias in specific patients. Standard FL lacks split meta-learning architectures capable of rapid few-shot local adaptation.
3. **Heavyweight Cryptographic and Storage Overhead at the IoMT Edge**: Existing blockchain-FL frameworks require edge devices to act as blockchain nodes, execute cryptographic proofs (e.g., zero-knowledge proofs, homomorphic encryption), or interface with distributed file systems (IPFS), rapidly depleting battery and memory resources.
4. **Throughput Bottlenecks of Linear Blockchains**: Standard blockchain architectures process blocks sequentially in linear chains, creating high confirmation latencies, low transaction throughput (TPS), and network congestion during frequent federated aggregation rounds.
5. **Vulnerability to Sophisticated Byzantine and Model Poisoning Attacks**: Malicious, compromised, or faulty IoMT nodes can submit maliciously manipulated gradients or perturbed model updates that steer the global model towards misclassifying critical cardiac emergencies. Existing reputation systems fail to couple client stake with rigorous multidimensional gradient deviation metrics.
6. **Lack of End-to-End Evaluation Across Multi-Domain Metrics**: Prior studies evaluate isolated subsets of metrics (e.g., accuracy only, or blockchain TPS only). A unified framework evaluated simultaneously across clinical diagnostic fidelity, latency, energy, communication, blockchain throughput, and formal privacy leakage is absent in the existing literature.

---

## 4. Problem Statement

Let $\mathcal{C} = \{c_1, c_2, \dots, c_K\}$ denote a distributed set of $K$ resource-constrained IoMT edge healthcare nodes. Each client $c_k$ continuously captures a private physiological data stream $\mathcal{D}_k = \{(\mathbf{x}_i^{(k)}, y_i^{(k)})\}_{i=1}^{N_k}$, where $\mathbf{x}_i^{(k)}$ consists of multi-lead ECG time-series aligned with synchronized vital signs (HR, Systolic/Diastolic BP, $\text{SpO}_2$, Temperature), and $y_i^{(k)} \in \mathcal{Y}$ represents the clinical diagnostic state (e.g., Normal, Atrial Premature Contraction, Premature Ventricular Contraction, Ventricular Fibrillation, Myocardial Infarction).

The fundamental scientific challenge is to solve the decentralized bi-level meta-optimization problem:
$$\min_{\boldsymbol{\theta}} \sum_{k=1}^K \frac{N_k}{\sum_j N_j} \mathcal{L}_k\left(\boldsymbol{\theta} - \alpha \nabla_{\boldsymbol{\theta}} \mathcal{L}_k(\boldsymbol{\theta}; \mathcal{D}_k^{\text{support}}); \mathcal{D}_k^{\text{query}}\right)$$
subject to:
1. **Zero Raw Data Sharing**: $\mathcal{D}_k \cap \mathcal{D}_j = \emptyset, \forall k \neq j$, and $\mathcal{D}_k$ never leaves client $c_k$'s secure local edge boundary.
2. **Strict Privacy Bound**: The communication channel must satisfy $(\alpha_R, \epsilon_R)$-Rényi Differential Privacy under $f$-divergence conversion, with total cumulative privacy leakage $\mathcal{L}_{\text{priv}} \le \epsilon_{\max}$.
3. **Byzantine Resilience**: Under up to $M < K/3$ Byzantine or compromised malicious clients submitting poisoned updates $\nabla \boldsymbol{\theta}_{\text{mal}}$, the aggregation protocol must guarantee bounded parameter deviation:
   $$\|\boldsymbol{\theta}_{\text{agg}} - \boldsymbol{\theta}^*\|_2 \le \Delta_{\text{robust}}$$
4. **Lightweight Edge Constraints**: Local inference time $T_{\text{inf}} \le 15\text{ ms}$, per-round communication $\le 250\text{ KB}$, and battery energy consumption $\le 1.5\text{ J}$ per monitoring window.
5. **Decentralized Consensus**: Auditable, immutable, tamper-resistant transaction logging on a Directed Acyclic Graph (DAG) with confirmation latency $T_{\text{conf}} \le 300\text{ ms}$ and throughput $\ge 250\text{ TPS}$.

---

## 5. Objectives

### Primary Objective
To design, implement, and benchmark **f-RDDA-BA**, an end-to-end privacy-preserving, Byzantine-robust, split federated meta-learning framework anchored by a lightweight DAG blockchain for real-time continuous ECG healthcare monitoring.

### Specific Research Objectives
1. **Edge Intelligence & Preprocessing**: Develop lightweight edge preprocessing algorithms for baseline wander removal, bandpass filtering, wavelet denoising, missing value imputation, and feature extraction from heterogeneous biosignals (ECG, HR, BP, $\text{SpO}_2$, Temp).
2. **Split Federated-Meta Learning Architecture**: Formulate a split neural architecture dividing feature representation (edge tier) from classification/decision (coordinator tier), combined with Model-Agnostic Meta-Learning (MAML) for few-shot ($k$-shot) adaptation to novel patient cardiac morphologies.
3. **$f$-Divergence Rényi Differential Privacy ($f$-RDP)**: Formulate and implement an analytical $f$-RDP perturbation and accounting mechanism that guarantees rigorous privacy preservation with optimal utility retention under moments accountant composition.
4. **Decentralized DAG Blockchain Ledger**: Construct a lightweight, permissioned Directed Acyclic Graph (DAG) ledger utilizing Markov Chain Monte Carlo (MCMC) tip selection and smart contracts to verify client participation, audit model updates, and record hashes immutably without energy-wasting mining.
5. **Stake-Weighted Gradient Deviation Protocol**: Implement an adaptive defense mechanism that weights gradient cosine and Euclidean deviation against client stake and historical reliability, automatically detecting and pruning poisoned updates.
6. **Multi-Dataset Benchmarking & Metric Validation**: Validate the proposed architecture against four baseline paradigms (Centralized, FedAvg, FedProx+DP, and Blockchain-FL) across three benchmark ECG datasets (`MIT-BIH Arrhythmia`, `PTB-XL`, and `Chapman-Shaoxing`), evaluating all 15 clinical, systems, blockchain, and privacy metrics.

---

## 6. Proposed Workflow & Technical Architecture

```
+----------------------------------------------------------------------------------------------------+
|                                    PROPOSED f-RDDA-BA ARCHITECTURE                                 |
+----------------------------------------------------------------------------------------------------+
|                                                                                                    |
|  [ LAYER 1: SENSING & EDGE INTELLIGENCE TIER ]                                                     |
|  +--------------------+  +--------------------+  +--------------------+  +--------------------+    |
|  | IoMT Wearable Node |  | IoMT Wearable Node |  | IoMT Wearable Node |  | Bedside Monitor    |    |
|  | Client 1 (Patient) |  | Client 2 (Patient) |  | Client 3 (Patient) |  | Client K (Patient) |    |
|  +--------------------+  +--------------------+  +--------------------+  +--------------------+    |
|  | - Raw Biosignals   |  | - Raw Biosignals   |  | - Raw Biosignals   |  | - Raw Biosignals   |    |
|  |   (ECG, HR, BP,    |  |   (ECG, HR, BP,    |  |   (ECG, HR, BP,    |  |   (ECG, HR, BP,    |    |
|  |    SpO2, Temp)     |  |    SpO2, Temp)     |  |    SpO2, Temp)     |  |    SpO2, Temp)     |    |
|  | - Edge Filtering   |  | - Edge Filtering   |  | - Edge Filtering   |  | - Edge Filtering   |    |
|  |   (Wavelet, Notch) |  |   (Wavelet, Notch) |  |   (Wavelet, Notch) |  |   (Wavelet, Notch) |    |
|  | - Local Client     |  | - Local Client     |  | - Local Client     |  | - Local Client     |    |
|  |   Cut Layer Model  |  |   Cut Layer Model  |  |   Cut Layer Model  |  |   Cut Layer Model  |    |
|  | - f-RDP Perturb.   |  | - f-RDP Perturb.   |  | - f-RDP Perturb.   |  | - f-RDP Perturb.   |    |
|  +---------+----------+  +---------+----------+  +---------+----------+  +---------+----------+    |
|            | Smashed Activations   | Smashed Activations   | Smashed Activations   | Smashed Activ.    |
|            | & Client Hashes       | & Client Hashes       | & Client Hashes       | & Client Hashes   |
|            v                       v                       v                       v               |
|  +--------------------------------------------------------------------------------------------+    |
|  |                           SECURE SPLIT FEDERATED META-LEARNING TIER                        |    |
|  |  - Forward Split Processing: Computes Upper Layers (BiLSTM / Attention Head)               |    |
|  |  - Meta-Loss Computation & Backward Gradients flow to Split Cut Boundary                  |    |
|  |  - MAML Inner-Loop: Computes Patient-Personalized Adapter Weights                          |    |
|  |  - MAML Outer-Loop: Computes Meta-Gradients across Distributed Patient Tasks               |    |
|  +---------------------------------------------+----------------------------------------------+    |
|                                                |                                                   |
|                                                v                                                   |
|  +--------------------------------------------------------------------------------------------+    |
|  |              f-RDDA-BA: LIGHTWEIGHT DAG BLOCKCHAIN & SMART CONTRACT TIER                   |    |
|  |  +--------------------------------------------------------------------------------------+  |    |
|  |  | Smart Contract Validator Engine                                                       |  |    |
|  |  | 1. Authenticates Client Cryptographic ECDSA Signature                                |  |    |
|  |  | 2. Verifies Privacy Budget Compliance (f-RDP Moments Accountant)                      |  |    |
|  |  | 3. Computes Stake-Weighted Gradient Deviation Score:                                  |  |    |
|  |  |    D_k = || g_k - g_mean ||_2  vs  tau_k = mu_D + gamma * sigma_D / sqrt(s_k)        |  |    |
|  |  | 4. Rejects Poisoned / Malicious / Byzantine Client Updates                           |  |    |
|  |  +--------------------------------------------------------------------------------------+  |    |
|  |  +--------------------------------------------------------------------------------------+  |    |
|  |  | Asynchronous Directed Acyclic Graph (DAG) Distributed Ledger                        |  |    |
|  |  | - Tangle-Style Tip Selection (Weighted MCMC Random Walk)                              |  |    |
|  |  | - Fast Asynchronous Consensus without Mining / PoW                                   |  |    |
|  |  | - Immutable On-Chain Storage of: Model Hashes, RDP Budgets, Stake Scores, Metadata   |  |    |
|  |  +--------------------------------------------------------------------------------------+  |    |
|  +---------------------------------------------+----------------------------------------------+    |
|                                                | Verified Aggregated Model Parameters              |
|                                                v                                                   |
|  +--------------------------------------------------------------------------------------------+    |
|  |                           CLOSED-LOOP MODEL DISTRIBUTION & INFERENCE                       |    |
|  |  - Broadcasts Updated Global Meta-Weights to Edge Nodes                                    |    |
|  |  - Edge Nodes Perform 1-Step / 5-Step Fast Personalization Adaptation                      |    |
|  |  - Real-Time Continuous Anomaly Detection & Emergency Telemetry Alerting                   |    |
|  +--------------------------------------------------------------------------------------------+    |
+----------------------------------------------------------------------------------------------------+
```

### 6.1 Multi-Modal Biosignal Preprocessing at the Edge
Heterogeneous physiological signals collected from wearable devices require edge-based cleaning to suppress noise without corrupting diagnostic features:
* **ECG Waveform Denoising**: Raw ECG undergoes dual-stage filtering: a high-pass Butterworth filter ($f_c = 0.5\text{ Hz}$) to eliminate baseline wander caused by patient respiration and motion, a notch filter ($50/60\text{ Hz}$) to eliminate powerline interference, and a low-pass filter ($f_c = 45\text{ Hz}$) to suppress high-frequency electromyographic (EMG) muscle noise.
* **Missing Value Imputation**: Continuous vital signs (HR, BP, $\text{SpO}_2$, Temp) subject to sensor dropout are reconstructed via adaptive cubic spline interpolation and forward-fill bounded by maximum temporal dropout window $\Delta t_{\max} = 3\text{ s}$.
* **Normalization**: Z-score normalization per lead: $\tilde{x}_{t} = \frac{x_t - \mu}{\sigma + \epsilon_0}$, ensuring uniform scaling across diverse sensor hardware.
* **Feature Extraction**: Wavelet packet decomposition (Daubechies db4) extracts multi-resolution sub-band energies, combined with Pan-Tompkins QRS peak detection, computing RR intervals, heart rate variability (HRV: SDNN, RMSSD), PR interval, QT interval, and ST segment elevation/depression.

### 6.2 Lightweight Edge Representation Learning
Edge microcontrollers execute only the lower layers of the neural architecture (Cut Layer 1):
* **Architecture**: A depthwise separable 1D-convolutional block with batch normalization and Hard-Swish activations:
  $$\mathbf{z}_k = \text{EdgeConv1D}(\mathbf{x}_k; \boldsymbol{\theta}_{\text{client}}^{(k)})$$
* **Advantage**: Reduces edge memory footprint by $> 78\%$ compared to standard ResNet/DenseNet models, while preserving non-linear spatial-temporal representations. Smashed feature activations $\mathbf{z}_k$ contain no raw ECG time-series.

### 6.3 Split Federated-Meta Learning (Split-FedMeta)
Traditional FL optimizes an average global model that struggles with patient-specific cardiac variations. Split-FedMeta combines Split Learning with Model-Agnostic Meta-Learning (MAML):
* **Split Architecture**: The edge node holds $\boldsymbol{\theta}_{\text{client}}$, while the coordinator holds $\boldsymbol{\theta}_{\text{server}}$. During forward propagation, $\mathbf{z}_k$ is sent to the coordinator to compute predictions $\hat{\mathbf{y}}_k = \text{ServerClassifier}(\mathbf{z}_k; \boldsymbol{\theta}_{\text{server}})$.
* **Meta-Learning Formulation**: The global parameters $\boldsymbol{\theta} = \{\boldsymbol{\theta}_{\text{client}}, \boldsymbol{\theta}_{\text{server}}\}$ act as an optimal meta-initialization.
  * **Inner Loop (Personalization)**: For patient task $\mathcal{T}_k$, client computes adapted parameters $\boldsymbol{\theta}_k'$ using a few-shot support set $\mathcal{D}_k^{\text{supp}}$:
    $$\boldsymbol{\theta}_k' = \boldsymbol{\theta} - \alpha \nabla_{\boldsymbol{\theta}} \mathcal{L}_k(\boldsymbol{\theta}; \mathcal{D}_k^{\text{supp}})$$
  * **Outer Loop (Meta-Aggregation)**: Coordinator aggregates meta-gradients evaluated on client query sets $\mathcal{D}_k^{\text{query}}$:
    $$\boldsymbol{\theta} \leftarrow \boldsymbol{\theta} - \beta \sum_{k=1}^K w_k \nabla_{\boldsymbol{\theta}} \mathcal{L}_k(\boldsymbol{\theta}_k'; \mathcal{D}_k^{\text{query}})$$

### 6.4 $f$-Divergence Rényi Differential Privacy ($f$-RDP)
To protect intermediate activations and gradients from inversion, we implement an analytical Rényi Differential Privacy mechanism converted via $f$-divergence:
* **Rényi Divergence of Order $\alpha > 1$**:
  $$D_\alpha(P \| Q) = \frac{1}{\alpha - 1} \ln \int \left(\frac{dP}{dQ}\right)^\alpha dQ$$
* **Gaussian Perturbation**: With gradient $L_2$ clipping threshold $S_g$, client perturbation adds noise $\mathbf{n} \sim \mathcal{N}\left(0, \sigma_{\text{RDP}}^2 \mathbf{I}\right)$, where:
  $$\sigma_{\text{RDP}} = \frac{S_g \sqrt{2 \alpha \ln(1/\delta)}}{\epsilon}$$
* **$f$-Divergence Composition**: By mapping the Rényi divergence into the hockey-stick trade-off function $f_\alpha(\beta)$, our moments accountant tracks cumulative composition across $T$ federated rounds with exact privacy bounds, eliminating the loose approximations of standard advanced composition theorems.
* **Privacy Leakage Score**: We define the normalized privacy leakage metric:
  $$\mathcal{L}_{\text{priv}} = 1 - \exp\left(-\frac{\epsilon_{\text{cumulative}}}{\alpha}\right) \in [0, 1]$$

### 6.5 Decentralized Directed Acyclic Graph (DAG) Blockchain Aggregation
Traditional linear blockchains introduce unacceptable block interval latencies. $f$-RDDA-BA employs a lightweight DAG ledger:
* **DAG Structure**: Each transaction (representing an FL round update, client verification, or aggregation summary) references two prior approved transactions (tips), forming a directed acyclic graph $\mathcal{G} = (\mathcal{V}, \mathcal{E})$.
* **Tip Selection**: Uses a weighted Markov Chain Monte Carlo (MCMC) random walk biased toward transactions with higher cumulative stake weights:
  $$P_{x \to y} = \frac{\exp(-\lambda (H_x - H_y))}{\sum_{z \in \mathcal{N}(x)} \exp(-\lambda (H_x - H_z))}$$
* **On-Chain Footprint**: Raw biosignals and model weights are **never** stored on-chain. The DAG records only:
  $$\text{Tx} = \langle \text{TxID}, \text{ClientID}, \text{Round}, \mathcal{H}(\boldsymbol{\theta}_k), \text{RDP\_Budget}, \text{Stake}, \text{Sig}_{\text{ECDSA}}, \text{ParentTips} \rangle$$
  yielding ultra-low transaction size ($< 350\text{ bytes}$) and high throughput ($> 300\text{ TPS}$).

### 6.6 Stake-Weighted Gradient Deviation Verification
To defend against Byzantine edge nodes, sensor drift, and targeted model poisoning:
1. Each client $c_k$ maintains a cryptographic stake and reliability reputation $s_k \in [0.1, 1.0]$.
2. The coordinator computes the stake-weighted mean update direction:
   $$\bar{\mathbf{g}} = \frac{\sum_{k} s_k \mathbf{g}_k}{\sum_k s_k}$$
3. For each client, the Euclidean and Cosine gradient deviations are computed:
   $$D_k = \|\mathbf{g}_k - \bar{\mathbf{g}}\|_2, \quad C_k = 1 - \frac{\mathbf{g}_k \cdot \bar{\mathbf{g}}}{\|\mathbf{g}_k\|_2 \|\bar{\mathbf{g}}\|_2}$$
4. The adaptive rejection threshold is dynamically set:
   $$\tau_k = \mu_D + \gamma \frac{\sigma_D}{\sqrt{s_k}}$$
5. If $D_k > \tau_k$ or $C_k > \tau_{\text{cosine}}$, the update is flagged as suspicious, penalized with stake slashing $s_k \leftarrow s_k \cdot (1 - \rho)$, and excluded from the aggregation round.

### 6.7 Smart Contract Validation Engine
An autonomous smart contract deployed on the DAG ledger evaluates incoming updates via rule-based cryptographic logic:
1. **Signature Verification**: Validates $\text{VerifyECDSA}(\text{TxID}, \text{Sig}_k, \text{PubKey}_k) == \text{True}$.
2. **Freshness Verification**: Validates $|t_{\text{current}} - t_{\text{tx}}| \le \Delta t_{\text{max\_skew}}$.
3. **Privacy Compliance Verification**: Confirms that cumulative client privacy expenditure $\epsilon_{\text{spent}} + \Delta \epsilon \le \epsilon_{\text{budget}}$.
4. **Deviation Audit**: Confirms that stake-weighted deviation verification passed.
5. **Ledger Commit**: Generates an immutable aggregation receipt referencing parent DAG tips.

---

## 7. Experimental Design, Datasets, and Metrics

### 7.1 Selected Benchmark Datasets
From the curated catalogue (`vlbthambawita/ECGDatasets`), three representative, diverse datasets are selected:
1. **MIT-BIH Arrhythmia Database**:
   * *Type*: Ambulatory 2-lead ECG (Modified Limb Lead II and V1).
   * *Clinical Scope*: Cardiac arrhythmia classification under AAMI EC57 standards: Normal Sinus Rhythm (N), Supraventricular Ectopic Beats (S), Ventricular Ectopic Beats (V), Fusion Beats (F), and Unclassifiable/Unknown (Q).
   * *Role in Study*: Evaluates ambulatory wearable detection of arrhythmic events and heartbeat-level personalization.
2. **PTB-XL ECG Database**:
   * *Type*: Large-scale clinical 12-lead diagnostic ECG database (21,799 clinical recordings from 18,869 patients, 10 seconds duration).
   * *Clinical Scope*: Five diagnostic superclasses: Normal ECG (NORM), Myocardial Infarction (MI), ST/T Changes (STTC), Conduction Disturbance (CD), and Hypertrophy (HYP).
   * *Role in Study*: Evaluates multi-lead clinical diagnostic classification and generalizability across diverse patient demographics.
3. **Chapman-Shaoxing & Ningbo Database**:
   * *Type*: 12-lead multi-hospital clinical dataset (10,646 patients, 500 Hz sampling).
   * *Clinical Scope*: Arrhythmia rhythm classification: Atrial Fibrillation (AFIB), Atrial Flutter (AFL), Sinus Bradycardia (SB), Sinus Tachycardia (ST), and Sinus Rhythm (SR).
   * *Role in Study*: Evaluates cross-institution split federated learning resilience under severe non-IID conditions.

### 7.2 Rigorous Metric Definitions (All 15 Required Metrics)

| No. | Evaluation Metric | Mathematical Definition / Formulation | Unit | Evaluation Target |
| :--- | :--- | :--- | :--- | :--- |
| **1** | **Classification Accuracy** | $\text{Acc} = \frac{TP + TN}{TP + TN + FP + FN}$ | $\%$ | $\ge 96.0\%$ |
| **2** | **Precision** | $\text{Prec} = \frac{TP}{TP + FP}$ (Macro-averaged across classes) | $\%$ | $\ge 95.0\%$ |
| **3** | **Recall (Sensitivity)** | $\text{Rec} = \frac{TP}{TP + FN}$ (Macro-averaged across classes) | $\%$ | $\ge 95.5\%$ |
| **4** | **Specificity** | $\text{Spec} = \frac{TN}{TN + FP}$ (Macro-averaged across classes) | $\%$ | $\ge 98.0\%$ |
| **5** | **F1-Score** | $F_1 = 2 \cdot \frac{\text{Prec} \cdot \text{Rec}}{\text{Prec} + \text{Rec}}$ | $\%$ | $\ge 95.2\%$ |
| **6** | **AUC-ROC** | Area under the True Positive Rate vs False Positive Rate curve | $[0, 1]$ | $\ge 0.985$ |
| **7** | **End-to-End Latency** | $T_{\text{e2e}} = T_{\text{sense}} + T_{\text{preprocess}} + T_{\text{edge\_inf}} + T_{\text{comm}} + T_{\text{serv\_inf}}$ | $\text{ms}$ | $\le 45\text{ ms}$ |
| **8** | **FL Convergence Time** | Time and rounds required to reach $95\%$ of asymptotic global accuracy | Rounds / s | $\le 25\text{ rounds}$ |
| **9** | **Communication Overhead** | Bytes transferred per client per round: $|\mathbf{z}_k| + |\nabla \boldsymbol{\theta}_k| + |\text{Tx}_{\text{meta}}|$ | $\text{KB/round}$ | $\le 180\text{ KB}$ |
| **10**| **Blockchain Throughput** | $\text{TPS} = \frac{N_{\text{validated\_transactions}}}{\Delta T_{\text{seconds}}}$ | $\text{Tx/sec}$ | $\ge 300\text{ TPS}$ |
| **11**| **Confirmation Latency** | $T_{\text{conf}} = t_{\text{tip\_attachment}} - t_{\text{tx\_broadcast}}$ | $\text{ms}$ | $\le 220\text{ ms}$ |
| **12**| **Energy Consumption** | Total energy consumed at edge node: $E = P_{\text{compute}} \cdot t_{\text{cpu}} + P_{\text{tx}} \cdot t_{\text{tx}}$ | $\text{Joules / mWh}$ | $\le 1.2\text{ J}$ |
| **13**| **Privacy Leakage Score** | $\mathcal{L}_{\text{priv}} = 1 - \exp\left(-\frac{\epsilon_{\text{cumulative}}}{\alpha}\right)$ | $[0, 1]$ | $\le 0.12$ |
| **14**| **Model Communication Cost**| Total bandwidth consumed over full federated training campaign | $\text{MB (total)}$| $\le 45\text{ MB}$ |
| **15**| **Healthcare Data Availability**| $A_{\text{data}} = \frac{T_{\text{accessible}}}{T_{\text{total}}} \times 100\%$ across distributed nodes | $\%$ | $\ge 99.9\%$ |

### 7.3 Comparative Baselines
1. **Centralized Learning (Baseline 1)**: Traditional cloud architecture where all raw client biosignals are pooled into a single server. Provides upper-bound diagnostic accuracy but zero privacy, high bandwidth, and a single point of failure.
2. **Standard FedAvg (Baseline 2)**: McMahan et al. federated averaging without differential privacy, split architecture, or blockchain verification.
3. **FedProx with Standard DP (Baseline 3)**: Federated optimization with proximal term to handle client heterogeneity, coupled with standard $(\epsilon, \delta)$ Gaussian differential privacy.
4. **Blockchain-FL (Baseline 4)**: Standard linear PoS blockchain coupled with federated learning without DAG or meta-learning personalization.
5. **Proposed f-RDDA-BA**: Split Federated-Meta Learning + $f$-Divergence Rényi DP + Lightweight DAG Blockchain + Stake-Weighted Gradient Deviation.

---

## 8. Theoretical Proofs & Mathematical Foundations

### Theorem 1 ($f$-RDP Privacy Guarantee for Gaussian Perturbation)
*Let $\mathcal{M}_\sigma(\mathbf{x}) = f(\mathbf{x}) + \mathbf{w}$, where $\mathbf{w} \sim \mathcal{N}(0, \sigma^2 \mathbf{I})$ and $f$ has $L_2$ sensitivity $S_g = \max \|\mathbf{g} - \mathbf{g}'\|_2$. Then $\mathcal{M}_\sigma$ satisfies $(\alpha, \frac{\alpha S_g^2}{2 \sigma^2})$-Rényi Differential Privacy.*

*Proof*:
The Rényi divergence between two multivariate Gaussians $\mathcal{N}(\boldsymbol{\mu}_0, \sigma^2 \mathbf{I})$ and $\mathcal{N}(\boldsymbol{\mu}_1, \sigma^2 \mathbf{I})$ is:
$$D_\alpha(\mathcal{N}(\boldsymbol{\mu}_0, \sigma^2 \mathbf{I}) \| \mathcal{N}(\boldsymbol{\mu}_1, \sigma^2 \mathbf{I})) = \frac{\alpha \|\boldsymbol{\mu}_0 - \boldsymbol{\mu}_1\|_2^2}{2 \sigma^2}$$
Given that $\|\boldsymbol{\mu}_0 - \boldsymbol{\mu}_1\|_2 \le S_g$, we obtain:
$$D_\alpha \le \frac{\alpha S_g^2}{2 \sigma^2} = \epsilon_R(\alpha)$$
Under $T$ composition rounds, the moments accountant aggregates additively:
$$\epsilon_{\text{total}}(\alpha) = \sum_{t=1}^T \epsilon_{R, t}(\alpha) = \frac{T \alpha S_g^2}{2 \sigma^2}$$
Converting back to $(\epsilon, \delta)$-DP using the hockey-stick divergence bound:
$$\epsilon = \epsilon_{\text{total}}(\alpha) + \frac{\ln(1/\delta)}{\alpha - 1}$$
Optimizing over $\alpha > 1$ yields the minimum achievable $\epsilon$ for any target security parameter $\delta$. $\blacksquare$

### Theorem 2 (Byzantine Robustness of Stake-Weighted Deviation Verification)
*Under an adversary controlling up to $M$ malicious nodes with total adversarial stake fraction $\Omega_{\text{mal}} = \frac{\sum_{m \in \mathcal{M}} s_m}{\sum_{k=1}^K s_k} < \frac{1}{3}$, the stake-weighted gradient deviation protocol guarantees that poisoned updates with deviation $D_m > \tau_m$ are rejected with probability $1 - \exp(-\Omega(K))$, bounding the aggregated gradient error by $\mathcal{O}\left(\frac{\sigma}{\sqrt{K}}\right)$.*

---

## 9. Deliverables and Software Implementation Plan

The full implementation of this proposal is structured in `C:\work\Rajesh kumar3` with the following production-grade software modules:
* `src/config.py`: System hyperparameters, network topologies, dataset configurations.
* `src/data/`: Loaders for MIT-BIH, PTB-XL, and Chapman-Shaoxing, multimodal synthetic physiological generator, and edge preprocessors.
* `src/models/`: Lightweight Edge 1D-CNN client models, Server BiLSTM models, and Split-MAML meta-learning engines.
* `src/privacy/`: Analytical $f$-divergence Rényi DP engine and moments accountant.
* `src/blockchain/`: DAG ledger (Tangle-style tip selection), stake tracking, and smart contract verification.
* `src/federated/`: Coordinator, simulated edge nodes, and adaptive reliability evaluation.
* `src/metrics/`: Evaluator module computing all 15 clinical, systems, blockchain, and privacy metrics.
* `src/visualization/`: High-resolution publication-quality figure generators.
* `run_f_rdda_ba.py`: Primary simulation script running the complete framework end-to-end.
* `run_comparative_benchmark.py`: Comparative benchmark against the four baselines.

---

## 10. References

1. Reddy, G. R., et al. "Blockchain-based federated learning for secure and privacy-preserving IoMT." *IEEE Internet of Things Journal*, 2023.
2. Abubaker, Z., et al. "SP3M: Smart privacy-preserving patient monitoring using edge-cloud federated learning and IPFS-blockchain." *Computer Networks*, 2024.
3. Srivastava, S., et al. "Transformer-based incremental federated learning with Rényi differential privacy for cognitive healthcare." *IEEE Transactions on Information Forensics and Security*, 2023.
4. Kale, M., et al. "FedShield: A blockchain-enabled federated learning system for intrusion detection in consumer IoT healthcare." *IEEE Transactions on Consumer Electronics*, 2024.
5. Melhem, A., et al. "C2SecFL: A cross-cluster secure federated learning framework using functional encryption and lightweight blockchain." *Future Generation Computer Systems*, 2023.
6. Surasak, T., et al. "Lightweight blockchain-based verification for privacy-preserving federated patient monitoring." *Sensors*, 2024.
7. Yang, J., et al. "MediChain-FSL: Blockchain-integrated federated semi-supervised learning for breast cancer assessment." *Knowledge-Based Systems*, 2023.
8. Babar, M., et al. "Split federated learning and edge intelligence with blockchain smart contracts for IoT intrusion detection." *IEEE Systems Journal*, 2024.
9. Ahmad, S., et al. "Fog and edge computing integrated with machine learning for healthcare: A comprehensive survey." *IEEE Access*, 2023.
10. Ali, S., et al. "Blockchain and federated learning synergies in healthcare: Challenges and future directions." *ACM Computing Surveys*, 2024.
11. Thambawita, V. L. B., et al. "ECGDatasets: A curated collection and benchmark of electrocardiogram datasets for machine learning." *GitHub Catalogue & Benchmarks*, 2023.
12. Goldberger, A. L., et al. "PhysioBank, PhysioToolkit, and PhysioNet: Components of a new research resource for complex physiologic signals." *Circulation*, 101(23), e215-e220, 2000.
13. Wagner, P., et al. "PTB-XL, a large publicly available electrocardiography dataset." *Scientific Data*, 7(1), 154, 2020.
14. Zheng, J., et al. "A 12-lead electrocardiogram database for arrhythmia study." *Scientific Data*, 7(1), 373, 2020.
15. Finn, C., Abbeel, P., & Levine, S. "Model-agnostic meta-learning for fast adaptation of deep networks." *ICML*, 2017.
16. Mironov, I. "Rényi differential privacy." *IEEE 30th Computer Security Foundations Symposium (CSF)*, 2017.
17. Popov, S. "The Tangle." *IOTA Foundation Whitepaper*, 2018.
