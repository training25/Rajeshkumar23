# Comprehensive Metrics Specification: f-RDDA-BA Evaluation Framework

This document defines the mathematical equations, measurement units, evaluation procedures, and clinical/technical relevance for all **15 performance metrics** stipulated in the research proposal.

---

## 1. Clinical Diagnostic Performance Metrics

### Metric 1: Classification Accuracy
* **Definition**: The proportion of correctly classified physiological segments (true positives and true negatives) across all diagnostic categories.
* **Formula**:
  $$\text{Accuracy} = \frac{\sum_{c=1}^C TP_c}{\sum_{c=1}^C (TP_c + FP_c + FN_c + TN_c)}$$
* **Unit**: Percentage ($\%$)
* **Clinical Target**: $\ge 96.0\%$

### Metric 2: Precision (Positive Predictive Value)
* **Definition**: The ratio of correctly identified cardiac abnormalities to all instances flagged as abnormal. Macro-averaged across all $C$ diagnostic classes to prevent majority class bias.
* **Formula**:
  $$\text{Precision}_{\text{macro}} = \frac{1}{C} \sum_{c=1}^C \frac{TP_c}{TP_c + FP_c}$$
* **Unit**: Percentage ($\%$)
* **Clinical Target**: $\ge 95.0\%$

### Metric 3: Recall (Sensitivity)
* **Definition**: The proportion of true cardiac abnormalities correctly recognized by the model. Critical for avoiding false negatives that could result in unmonitored fatal events.
* **Formula**:
  $$\text{Recall}_{\text{macro}} = \frac{1}{C} \sum_{c=1}^C \frac{TP_c}{TP_c + FN_c}$$
* **Unit**: Percentage ($\%$)
* **Clinical Target**: $\ge 95.5\%$

### Metric 4: Specificity (True Negative Rate)
* **Definition**: The proportion of normal/healthy segments correctly classified as non-pathological, minimizing false alarm fatigue in clinical telemetry wards.
* **Formula**:
  $$\text{Specificity}_{\text{macro}} = \frac{1}{C} \sum_{c=1}^C \frac{TN_c}{TN_c + FP_c}$$
* **Unit**: Percentage ($\%$)
* **Clinical Target**: $\ge 98.0\%$

### Metric 5: F1-Score (Harmonic Mean)
* **Definition**: The balanced harmonic mean of precision and recall, reflecting model robustness on severely imbalanced arrhythmia datasets.
* **Formula**:
  $$F_1 = 2 \times \frac{\text{Precision}_{\text{macro}} \times \text{Recall}_{\text{macro}}}{\text{Precision}_{\text{macro}} + \text{Recall}_{\text{macro}}}$$
* **Unit**: Percentage ($\%$)
* **Clinical Target**: $\ge 95.2\%$

### Metric 6: Area Under the ROC Curve (AUC-ROC)
* **Definition**: The integral of the True Positive Rate against the False Positive Rate across all discrimination thresholds, computed via one-vs-rest (OvR) multiclass averaging.
* **Formula**:
  $$\text{AUC-ROC} = \frac{1}{C} \sum_{c=1}^C \int_0^1 \text{TPR}_c(\tau) d\left(\text{FPR}_c(\tau)\right)$$
* **Unit**: Scalar $[0.0, 1.0]$
* **Clinical Target**: $\ge 0.985$

---

## 2. Computational & Convergence Metrics

### Metric 7: End-to-End Latency
* **Definition**: Total elapsed time from physiological sensor data acquisition to final classification output at the edge display or central station.
* **Formula**:
  $$T_{\text{e2e}} = T_{\text{sample}} + T_{\text{preprocess}} + T_{\text{client\_forward}} + T_{\text{network\_rtt}} + T_{\text{server\_forward}}$$
* **Unit**: Milliseconds ($\text{ms}$)
* **Target**: $\le 45.0\text{ ms}$

### Metric 8: Federated Learning Convergence Time
* **Definition**: Total wall-clock time and number of global communication rounds required for the federated meta-model to achieve $95\%$ of peak test accuracy.
* **Formula**:
  $$T_{\text{conv}} = \min \left\{ t \;\middle|\; \text{Acc}(t) \ge 0.95 \times \text{Acc}_{\text{asymptotic}} \right\}$$
* **Unit**: Rounds and Seconds ($\text{s}$)
* **Target**: $\le 25\text{ rounds}$ / $\le 180\text{ s}$

---

## 3. Communication & Resource Efficiency Metrics

### Metric 9: Communication Overhead
* **Definition**: Payload size exchanged between a client and the coordinator during a single federated training round, encompassing smashed activations, cut gradients, and blockchain transaction metadata.
* **Formula**:
  $$\Omega_{\text{round}} = |\mathbf{z}_{\text{client}}| + |\mathbf{g}_{\text{split}}| + |\text{Tx}_{\text{metadata}}|$$
* **Unit**: Kilobytes per round ($\text{KB/round}$)
* **Target**: $\le 180.0\text{ KB/round}$

### Metric 10: Model Communication Cost
* **Definition**: Cumulative network data transfer per edge client across the entire federated training campaign of $R$ rounds.
* **Formula**:
  $$\Omega_{\text{total}} = \sum_{r=1}^R \Omega_{\text{round}}(r)$$
* **Unit**: Megabytes ($\text{MB}$)
* **Target**: $\le 45.0\text{ MB}$

### Metric 11: Energy Consumption
* **Definition**: Average electrical energy consumed by an edge wearable microcontroller (MCU + BLE transceiver) during one complete data processing and update round.
* **Formula**:
  $$E_{\text{edge}} = P_{\text{cpu}} \cdot (T_{\text{prep}} + T_{\text{inf}} + T_{\text{rdp}}) + P_{\text{radio}} \cdot \left(\frac{\Omega_{\text{round}}}{\text{Bandwidth}}\right)$$
* **Unit**: Joules ($\text{J}$) and Milliwatt-hours ($\text{mWh}$)
* **Target**: $\le 1.2\text{ J}$ ($\le 0.33\text{ mWh}$)

---

## 4. Blockchain & Ledger Performance Metrics

### Metric 12: Blockchain Transaction Throughput (TPS)
* **Definition**: The sustained rate of validated and committed transaction records per second processed by the DAG consensus engine.
* **Formula**:
  $$\text{TPS} = \frac{N_{\text{validated\_transactions}}}{\Delta T_{\text{elapsed}}}$$
* **Unit**: Transactions Per Second ($\text{Tx/s}$)
* **Target**: $\ge 300\text{ TPS}$

### Metric 13: Blockchain Transaction Confirmation Latency
* **Definition**: Duration elapsed between transaction broadcast by an edge node and its permanent attachment to the DAG with milestone confirmation.
* **Formula**:
  $$T_{\text{conf}} = t_{\text{confirmed}} - t_{\text{broadcast}}$$
* **Unit**: Milliseconds ($\text{ms}$)
* **Target**: $\le 220.0\text{ ms}$

---

## 5. Privacy & System Resilience Metrics

### Metric 14: Privacy Leakage Score
* **Definition**: Normalized information-theoretic leakage bound derived from cumulative Rényi Differential Privacy under $f$-divergence conversion.
* **Formula**:
  $$\mathcal{L}_{\text{priv}} = 1 - \exp\left(-\frac{\epsilon_{\text{cumulative}}}{\alpha}\right)$$
* **Unit**: Normalized Index $[0.0, 1.0]$ ($0.0 = \text{Absolute Privacy}$, $1.0 = \text{Total Leakage}$)
* **Target**: $\le 0.12$

### Metric 15: Healthcare Data Availability
* **Definition**: The percentage of time that patient monitoring services, model updates, and audit records remain consistently accessible and fault-tolerant against Byzantine/failed nodes.
* **Formula**:
  $$\text{Availability} = \frac{T_{\text{uptime}}}{T_{\text{total}}} \times 100\% = \frac{N_{\text{successful\_requests}}}{N_{\text{total\_requests}}} \times 100\%$$
* **Unit**: Percentage ($\%$)
* **Target**: $\ge 99.9\%$
